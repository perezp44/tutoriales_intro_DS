#- hagamos algun mapa: por ejemplo los municipios con mas mujeres que hombres en 2016
#- https://github.com/perezp44/LAU2boundaries4spain
# https://github.com/perezp44/spanishRshapes
# https://perezp44.github.io/spanishRshapes/

library(tidyverse)
library(sf)
library(LAU2boundaries4spain) # devtools::install_github("perezp44/LAU2boundaries4spain", force = TRUE)
library(spanishRpoblacion)    # remotes::install_github("perezp44/spanishRpoblacion")

#- cargamos datos de lindes provinciales y municipales ------------------------------------------
Provincias <- Provincias   # cargamos en memoria el fichero de lindes provinciales
str(Provincias)
# plot(Provincias, max.plot = 1)                  #- las graficamos
Municipios_16 <- municipios_2016      # cargamos en memoria el fichero de lindes provinciales: 8.125 municipios + 84 condominios
str(Municipios_16)
# plot(Municipios_16, max.plot = 1)               #- las graficamos

#- cargamos datos de poblacion del Padron --------------------------------------------------------
pob <- INE_padron_muni_96_17  #- datos de poblacion del Padron


#- vamos a marcar con 1 los municipios q en 2016 tenían mas mujeres que hombres -------------------
pob_2016 <- pob %>% filter(anyo == 2016) %>%                   # en 2016 habían 8.125 municipios
                    select(INECodMuni, Pob_T, Pob_H, Pob_M)  %>%
                    mutate(Mas_M = ifelse(Pob_M > Pob_H, "Mas Mujeres", "Mas hombres"))

#- hemos de fusionar el df con los lineds/geometrias y el df con los datos de poblacion -----------
#- en el df con la poblacion hay 8.125 municipios, PERO en el de lindes hay 8.125+ 84 condominios

fusion_2016 <- full_join(Municipios_16, pob_2016)
fusion_2016_df <- fusion_2016 %>% st_set_geometry(NULL) #- le quitas la geometria para verlo mejor


#- ahora queda graficarlo  ¿que graficamos? Canarias?
df_peninsula <- fusion_2016 %>%  filter(!str_detect(INECodMuni, "^53")) %>%      #- quitamos los condominios
                                 filter(NombreCCAA != "Canarias")                #- quitamos canarias


#- paquete(s) para graficos espaciales
library(tmap)
library(viridisLite)

virpalette <- c("white", "#E41A1C") #-

#- Municipios de la peninsula con mas mujeres que hombres
gg_mas_mujeres <- tm_shape(df_peninsula, alpha = 0.3) +
  tm_fill(col = "Mas_M", palette = virpalette, title = "Municipios con mas mujeres que hombres") +
  tm_polygons(border.alpha = 0.6) +
  tm_layout(legend.position = c("right", "bottom"))

#- añadimos otra capa (con los linges provinciales) en el mapa
prov_peninsula <- Provincias %>%   filter(NombreCCAA != "Canarias")  #- quitamos canarias
gg_mas_mujeres <-  gg_mas_mujeres + tm_shape(prov_peninsula, alpha = 0.2) + tm_polygons(lwd = 1.8, border.col = "black", alpha = 0.2)

gg_mas_mujeres  #-el mapa

#- hagamos el mismo gráfico con leaflet
library(leaflet)
virpalette <- rev(viridis(2)) #- gracias Suzan


gg_mas_mujeres <- tm_shape(df_peninsula) +
  tm_fill(col = "Mas_M", palette = virpalette, title = "Municipios con mas mujeres que hombres", popup.vars = "NombreMuni") +
  tm_polygons() +
  tm_layout(legend.position = c("left", "bottom"))

gg_mas_mujeres_leaflet <- tmap_leaflet(gg_mas_mujeres)



#- MAS GRAFICOS -------------------------------------------------------------
#- MAS GRAFICOS -------------------------------------------------------------

