#- data beers: https://mkearney.github.io/nicar_tworkshop/#1

library(rtweet)
library(tidyverse)


#- un voluntario??
my_person <- "databeersvlc" #- @DataUv
usr <- lookup_users(my_person)


#- quienes son tus seguidores??
follow    <- get_followers(my_person)        #- id of the followers of an account
follow_x  <- lookup_users(follow$user_id)  #- details of the followers
follow_xx <- follow_x %>% select(user_id, screen_name, location, description,  followers_count, friends_count,  hashtags, text)



#- A quien sigues??
friend <- get_friends(my_person)
friend_x  <- lookup_users(friend$user_id)  #- details of the followers
friend_xx <- friend_x %>% select(user_id, screen_name, location, description,  followers_count, friends_count,  hashtags, text)



#- Vemos tus tweets, tu timeline??
timeline <- get_timeline(my_person, n = 100)
ts_plot(timeline, "weeks")


#- tus favoritos??
favorites <- get_favorites(my_person , n = 100)
ts_plot(favorites, "weeks")

jkr <- get_favorites("jk_rowling", n = 3000)

#------------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------------

#- busca 100 tweets con un hastag
rt <- search_tweets("#sociology", n = 100, include_rts = FALSE)
users <- search_users(q = "#sociology", n = 100, parse = TRUE)



#- search for multiple keywords
rt <- search_tweets(q = "rstats AND python", n = 120)
rt <- search_tweets("rstats", lang = "en", include_rts = FALSE)


#rt <- search_tweets("lang:es", geocode = lookup_coords("Valencia, Spain")) #- no funciona. API Google Maps



#- Get trends: Discover what’s currently trending in San Francisco.
sf <- get_trends("Valencia")



#- puede mandar tweets directamente desde R
#post_tweet("Los sociologos son muy listos #sociologia")

#- https://twitter.com/romain_francois/status/1115531328479485952/photo/1

#- https://cran.r-project.org/web/packages/rtweet/vignettes/stream.html

