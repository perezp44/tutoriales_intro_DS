#- ejemplo simple para familiarizarse un poco con el entorno de RStudio y la sintaxis de R
#- cargaremos unos datos de internet y haremos algunos gráficos

#- instalación de paquetes
#install.packages("tidyverse")
#install.packages("ggthemes")

#- cargamos paquetes en memoria (antes tienes que haberlos instalado en tu PC)
library(tidyverse)
library(ggthemes)

#- cargamos 2 conjuntos de datos -----
nivel_CO2   <- read.table("ftp://aftp.cmdl.noaa.gov/products/trends/co2/co2_annmean_mlo.txt")
temperatura <- read.table("https://go.nasa.gov/2r8ryH1", skip = 5)

#- veamos que datos hay en nivel_CO2 y en temperatura (son datos anuales)
str(nivel_CO2)
str(temperatura)

#- arreglamos un poco los datos -----
temperatura <- temperatura %>% rename(celsius = V2)                #- cambiamos el nombre de la v. V2 a "celsius"
temperatura <- temperatura %>% select(-V3)                         #- eliminamos V3 del df "temperatura"
temperatura <- temperatura %>% mutate(celsius_100 = celsius*100)   #- creamos la variable "celsius_100" como celsius*100

nivel_CO2 <- nivel_CO2 %>% rename(CO2 = V2)


#- fusionamos las 2 tablas (dataframes) de datos -----
datos <- inner_join(nivel_CO2, temperatura, by = "V1")

# hacemos gráficos con R-base -----
plot(datos$CO2, datos$celsius)

#- hacemos gráficos con el pkg ggplot2 -----
ggplot(datos, aes(CO2, celsius)) + geom_point()



#- hacemos más gráficos con ggplot2 -----
ggplot(datos, aes(CO2, celsius)) + geom_point() + geom_smooth()

ggplot(datos, aes(CO2, celsius)) + geom_point() + geom_smooth() + geom_smooth(method = "lm", colour = "red")

ggplot(datos, aes(CO2, celsius)) + geom_point() + geom_smooth(method = "lm") +
  xlab("CO2") + ylab("Temperatura") + theme_dark()

ggplot(datos, aes(CO2, celsius)) + geom_point() + geom_smooth(method = "lm") +
  labs(title = "Temperatura vs. CO2",
       subtitle = "1959-2018",
       caption = "https://go.nasa.gov/2r8ryH1",
       x = "Nivel de CO2")




#- veamos mas themes() -----
# https://yutannihilation.github.io/allYourFigureAreBelongToUs/ggthemes/
# http://www.ggplot2-exts.org/gallery/         #- pegadle un vistazo a esta gallery


my_plot <- ggplot(datos, aes(CO2, celsius)) + geom_point() + geom_smooth(method = "lm") +
              labs(title = "Temperatura vs. CO2",
                   subtitle = "1959-2018",
                   caption = "https://go.nasa.gov/2r8ryH1",
                   x = "Nivel de CO2")


my_plot  + theme_economist()

my_plot + theme_stata()

my_plot + theme_fivethirtyeight()

my_plot + theme_excel()

#- TAREA: poner la linea de regresión en "my_plot" de color verde [pista: colour = "green"]



#- planteamos y estimamos un modelo lineal ---
lm(formula = celsius ~ CO2, data = datos)

my_model <- lm(celsius ~ CO2, datos)
summary(my_model)


#- para hacer tablas hay multitud de paquetes. Por ejemplo
# install.packages("jtools")
library(jtools)
jtools::summ(my_model) #- https://cran.r-project.org/web/packages/jtools/vignettes/summ.html
summ(my_model, confint = TRUE, digits = 3) #- con intervalo de confianza


