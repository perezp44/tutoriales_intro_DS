#- bajar datos de la European Social Survey (ESS)
#- https://github.com/ropensci/essurvey

#devtools::install_github("ropensci/essurvey")
#install.packages("sjmisc")
library(tidyverse)
library(essurvey)
library(sjPlot)


#- por favor no utiliceis este script para bajaros datos sin antes registraros en: http://www.europeansocialsurvey.org/user/login?from=/download.html?file=ESS8e02_1&c=&y=2016 . Para resgistrarse solo hay que dar unos datos básicos y ya está.


set_email("tu-email@alumni.uv.es")  #- solo teneis que introducir el e-mail con el que os habéis registrado
#- ademas mirad las condiciones de uso: https://www.europeansocialsurvey.org/data/conditions_of_use.html


show_countries() #- paises que participan en la ESS

#first_round <- import_rounds(1) #- importa la primera ronda de la ESS
#first_round <-  first_round %>%  recode_missings()


# bajamos ESS para España -----------------------------------------------
show_country_rounds("Spain")

#spain_7_8 <- import_country("Spain", 7:8) #- bajamos la 7 y 8 ronda para España
#spain_8 <- spain_7_8[[2]]                    #- la octava round para Spain
#spain_8a <- spain_8 %>%  recode_missings()   #- arreglamos los "NAs"
#rio::export(spain_8a, "./datos/spain_ess_8.rds")
#rio::export(spain_8a, "./datos/spain_ess_8.xlsx")
spain <- rio::import("./datos/spain_ess_8.rds")


#- no funcionará si no bajas los datos con el bloque anterior
sjPlot::view_df(spain)  #- nos da un diccionario del df

#- veamos que hay en la ESS -----------------------------------------

names(spain)
library(sjlabelled)
aa <- get_label(spain) %>% as.data.frame()
bb <- names(spain) %>% as.data.frame()
names_spain <- bind_cols(bb, aa)
rm(aa,bb)


#remotes::install_github("perezp44/pjp.funs")
library(pjp.funs)
aa <- my_df_estadisticos_basicos(spain)

# seleccionamos algunas variables ----------------------------------
# trstplt:  Trust in politicians
# stflife:  How satisfied with life as a whole
# lrscale:  Placement on left right scale
# happy:    How happy are you
# rlgdgr:   How religious are you
# gndr:     Gender
# agea:     Age of respondent, calculated
# eisced:   Highest level of education, ES - ISCED
# wkhtot:   Total hours normally worked per week in main job overtime in
# hinctnta: Household's total net income, all sources
# imprich:  Important to be rich, have money and expensive things
# impfun:   Important to seek fun and things that give pleasure
#-----------------------------------------------------------------------
spain <- spain %>% select(gndr, agea, eisced, wkhtot, hinctnta, stflife, happy, imprich, impfun,  trstplt , lrscale)

spain <- spain %>% map_if(is.character, as.numeric) %>% as_tibble     #- las arreglamos un poco


#- usamos algunos paquetes para hacer EDA
library(summarytools)
view(dfSummary(spain))

aa <- my_df_estadisticos_basicos(spain)

library(visdat)
vis_dat(spain)

library(skimr) #- https://ropensci.github.io/skimr/index.html
spain %>% skim()

library(corrplot) #- https://cran.r-project.org/web/packages/corrplot/vignettes/corrplot-intro.html

M <- cor(spain, use = "pairwise.complete.obs", method = "pearson")
corrplot(M, method = "circle")
corrplot.mixed(M)



#- http://ncss-tech.github.io/stats_for_soil_survey/chapters/4_exploratory_analysis/4_exploratory_analysis.html  (para EDA)


ggplot(spain, aes(agea, wkhtot)) + geom_point()

ggplot(data = spain, aes(happy)) +
    geom_histogram(bins = 15, fill='gray') +
    geom_vline(xintercept = quantile(spain$happy, na.rm = TRUE), linetype="dashed", color="gray") +
    annotate("text", label= names(quantile(spain$happy, na.rm = TRUE)),
             x=quantile(spain$happy, na.rm = TRUE), y=28, size=3) +
    labs(
        title="Subjective happiness is highly skewed",
        subtitle="Weighted by survey/country scores",
        caption="ESS surveys 2002-2016") +
    theme_bw() +
    theme(
        panel.border = element_blank(),
        axis.title = element_text(size=6, color="gray"),
        plot.title = element_text(hjust = 0),
        plot.subtitle = element_text(hjust = 0)) +
    xlab("") + ylab("")




#- https://lindeloev.github.io/tests-as-linear/  #- test en el contexto de MRLM



#-- este no chuta x SPSS haven labelled !!!!!!
p <- ggplot(spain, aes(x = agea, y = happy, color = lrscale)) +
    stat_smooth(method = "lm", formula = y ~ 1) +
    geom_point(position = position_jitter(width = 0.1), shape = 1) +
    labs(x = "How satisfied with life as a whole", y = "Hapiness")






#- APA style: https://github.com/WinVector/sigr/
#- https://github.com/achetverikov/APAstats
#- https://github.com/achetverikov/apastats/blob/master/example/example.md


#- http://www.rpubs.com/juhariis/ess (ESS)
#- https://ropensci.org/blog/2018/06/14/essurvey/
#- https://strengejacke.wordpress.com/2016/11/14/pipe-friendly-workflow-with-sjplot-sjmisc-and-sjstats-part-1-rstats-tidyverse/
#- https://strengejacke.wordpress.com/2016/12/22/exploring-the-european-social-survey-ess-pipe-friendly-workflow-with-sjmisc-part-2-rstats-tidyverse/
#- https://campus.datacamp.com/courses/surv730-measurement-error-models/unit-2-estimating-measurement-error-in-continuous-variables?ex=1


#- y los datos del CIS??:
# https://www.datanalytics.com/2016/10/05/barometros-del-cis-con-r/
# https://twitter.com/kikollan/status/783315300720730112





