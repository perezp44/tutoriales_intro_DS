#- R-elecciones es un pkg de R para descargar resultados electorales oficiales de España del Ministerio del Interior. Permite descargar resultados de las elecciones generales y municipales de cualquier año a nivel de mesa electoral y de municipio.

#- https://github.com/hmeleiro/elecciones
#- https://r-elecciones.netlify.com/posts/ejemplo-muni/

#- http://www.infoelectoral.mir.es/infoelectoral/min/areaDescarga.html?method=search
#- https://www.resultados.eleccionesgenerales19.es/Congreso/Total-nacional/0/es

#- devtools::install_github("hmeleiro/elecciones")


library(elecciones)
generales.1979 <- municipios(tipoeleccion = "generales", yr = 1979, mes = "03")
results <- municipios("generales", "2015", "12") # Descargo los datos


