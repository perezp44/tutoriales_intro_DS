#- un gráfico de resultados electorales
#- un theme() para politólogos: https://github.com/erocoar/ggpol
#- Además la BBC ... ¿Cómo hace sus gráficos? https://medium.com/bbc-visual-and-data-journalism/how-the-bbc-visual-and-data-journalism-team-works-with-graphics-in-r-ed0b35693535


#devtools::install_github('erocoar/ggpol')
library(ggpol)

df_parlam <- data.frame(
  parties = factor(c("CDU", "CSU", "AfD", "FDP", "SPD", "Linke", "Gruene", "Fraktionslos"),
            levels = c("CDU", "CSU", "AfD", "FDP", "SPD", "Linke", "Gruene", "Fraktionslos")),
  seats   = c(200, 46, 92, 80, 153, 69, 67, 2),
  colors  = c("black", "blue", "lightblue", "yellow", "red","purple", "green", "grey")   )


ggplot(df_parlam) +
  geom_parliament(aes(seats = seats, fill = parties), color = "black") +
  scale_fill_manual(values = df_parlam$colors, labels = df_parlam$parties) +
  coord_fixed() +
  theme_void()



# TAREA: ¿qué pasara si en lugar de theme_void() usásemos otro theme()?
# TAREA: ¿le ponemos un titulo y substitulo al gráfico? Pista: labs(title = "Parlamento alemán", subtitle = "2018", caption = "R mola/presta")
