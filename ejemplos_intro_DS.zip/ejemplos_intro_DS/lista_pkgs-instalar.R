#- paquetes a instalar en tu ordenador. Instálalos en el orden en que aparecen
#- Tarda un ratito ...
install.packages(c("ggthemes", "jtools", "tidyverse"))
install.packages(c("rprojroot", "huxtable"))
install.packages("ggpol")
install.packages("eurostat")
install.packages(c("corrplot", "essurvey", "rio", "sjlabelled", "sjPlot", "skimr", "summarytools", "visdat"))
install.packages("remotes")
remotes::install_github("perezp44/pjp.funs")
install.packages(c("cowplot", "tabulizer"))
remotes::install_github("xvrdm/ggrough") 
install.packages("htmlwidgets")
install.packages("rtweet")
install.packages("gganimate")
install.packages("SPARQL")
install.packages("devtools")
devtools::install_github("hmeleiro/elecciones")
install.packages("meme")
install.packages(c("plotly", "spotifyr", "tidytext", "tm", "wordcloud2"))
install.packages(c("leaflet", "tmap"))
install.packages("pxR")
remotes::install_github("perezp44/personal.pjp")
remotes::install_github("perezp44/spanishRentidadesIGN")
remotes::install_github("perezp44/spanishRshapes")
install.packages("ggridges")
install.packages("OECD")
install.packages("datasauRus")
install.packages("gapminder")
install.packages("gifski")
#----------------------------------------- pkgs añadidos desde la primera clase
#----------------------------------------- pkgs añadidos desde la primera clase
install.packages("flextable")   #- hace falta para .Rmd
install.packages("fs")          #- hace falta jugar a exportar
install.packages("here")        #- hace falta jugar a exportar

#-----------------------------------
install.packages("tidyquant")
install.packages("quantmod")

#-----------------------------------
install.packages("knitr")
devtools::install_github("thomasp85/patchwork")
install.packages("gridExtra")
install.packages("viridis")
devtools::install_github("LKremer/ggpointdensity")
install.packages("ggrepel")
install.packages("janitor")
install.packages("GGally")
install.packages("ggThemeAssist")
install.packages("scales")
install.packages("ggforce")
install.packages("gghighlight")
install.packages("esquisse")

#----------------------------------- 15 Noviembre
install.packages("flexdashboard")
install.packages("rmdformats")
install.packages("vitae")
install.packages("learnr")
install.packages("scholar")
install.packages("tinytex")
install.packages("pagedown")
remotes::install_github("rstudio/gt")
install.packages(c("apaTables", "formattable", "kableExtra", "modelsummary", "rpivotTable", "stargazer", "xlsx"))
devtools::install_github("neuropsychology/report")

#------------------------------- 22 Noviembre
devtools::install_github("strengejacke/strengejacke") #- te preguntará si actualiza paquetes (sí, todos, escribe 1 en la consola)
devtools::install_github("laderast/burro")            #- te preguntará si actualiza paquetes (sí, todos, escribe 1 en la consola)
install.packages(c("corrr", "DataExplorer", "estimatr", "explore", "factoextra", "FactoMineR", "funModeling", "ggfortify", "ggparty", "inspectdf", "lmtest", "margins", "naniar", "NHANES", "psycho", "rattle"))
remotes::install_github("datalorax/equatiomatic")
install.packages("psycho")
install.packages("reportr")


#------------------------------- mapas
install.packages(c("ggspatial", "rnaturalearth", "rnaturalearthdata"))
install.packages(c("leafem", "leafpm", "mapedit", "mapview"))
install.packages("rworldmap")
install.packages("stationaRy")
remotes::install_github("adam-gruer/victor")  #- te preguntará si actualiza paquetes (sí, todos, escribe 1 en la consola)
install.packages(c("ggmap", "osmdata"))
install.packages("reactable")
remotes::install_github("juba/rmdformats")    #- te preguntará si actualiza paquetes (sí, todos, escribe 1 en la consola)
install.packages("googlePolylines")
install.packages("geojsonsf")
install.packages("geojsonlint")
remotes::install_github("GIScience/openrouteservice-r") #- te preguntará si actualiza paquetes (sí, todos, escribe 1 en la consola)

#------------------------------ 13 Diciembre
install.packages("httpuv")
install.packages("pageviews")
install.packages("graphTweets")
install.packages("syuzhet")             #- en Cloud no se ha podido instalar
install.packages("RSQLite")             #- en Cloud no se ha podido instalar
devtools::install_github("hadley/emo")  #- en Cloud no se ha podido instalar




#- estos tardan bastante xq son datos pesados pero hacen falta para los ej, 15,16 y siguientes
# remotes::install_github("perezp44/spanishRpoblacion")
# remotes::install_github("perezp44/LAU2boundaries4spain")

