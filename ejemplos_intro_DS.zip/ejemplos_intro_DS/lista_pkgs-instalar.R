#- paquetes a instalar en tu ordenador. Instálalos en el orden en que aparecen
#- Tarda un ratito ...
install.packages(c("ggthemes", "jtools", "tidyverse"))
install.packages(c("rprojroot", "huxtable"))
install.packages("ggpol")
install.packages("eurostat")
install.packages(c("corrplot", "essurvey", "rio", "sjlabelled", "sjPlot", "skimr", "summarytools", "visdat"))
install.packages("remotes")
remotes::install_github("perezp44/pjp.funs")
install.packages(c("cowplot", "tabulizer"))
remotes::install_github("xvrdm/ggrough") 
install.packages("htmlwidgets")
install.packages("rtweet")
install.packages("gganimate")
install.packages("SPARQL")
install.packages("devtools")
devtools::install_github("hmeleiro/elecciones")
install.packages("meme")
install.packages(c("plotly", "spotifyr", "tidytext", "tm", "wordcloud2"))
install.packages(c("leaflet", "tmap"))
install.packages("pxR")
remotes::install_github("perezp44/personal.pjp")
remotes::install_github("perezp44/spanishRentidadesIGN")
remotes::install_github("perezp44/spanishRshapes")
install.packages("ggridges")
install.packages("OECD")
install.packages("datasauRus")
install.packages("gapminder")
install.packages("gifski")
#----------------------------------- pkgs añadidos desde la primera clase
install.packages("flextable")   #- hace falta para .Rmd
install.packages("fs")          #- hace falta jugar a exportar
install.packages("here")        #- hace falta jugar a exportar

#-----------------------------------
install.packages("tidyquant")
install.packages("quantmod")

#-----------------------------------
install.packages("knitr")
devtools::install_github("thomasp85/patchwork")
install.packages("gridExtra")
install.packages("viridis")
devtools::install_github("LKremer/ggpointdensity")
install.packages("ggrepel")
install.packages("janitor")
install.packages("GGally")
install.packages("ggThemeAssist")
install.packages("scales")
install.packages("ggforce")
install.packages("gghighlight")
install.packages("esquisse")


#- estos tardan bastante xq son datos pesados pero hacen falta para los ej, 15,16 y siguientes
# remotes::install_github("perezp44/spanishRpoblacion")
# remotes::install_github("perezp44/LAU2boundaries4spain")
