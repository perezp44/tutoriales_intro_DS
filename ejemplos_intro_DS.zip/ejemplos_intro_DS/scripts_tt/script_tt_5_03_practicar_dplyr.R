#---- TUTORIAL 5: script para practicar con dplyr
library(tidyverse)
#- vamos a trabajar con el fichero de datos gapminder que está en esta dirección:
#- https://raw.githubusercontent.com/jennybc/gapminder/master/data/gapminder.rdata

#- REPASO de descargar e importar ficheros de datos
#- si quisieramos descargar los datos hariamos:
download.file("https://raw.githubusercontent.com/jennybc/gapminder/master/data/gapminder.rdata", 
              "./datos/pruebas/gapminder.rdata")
#- una vez los tenemos descargados en nuestro PC podemos importar/leer esos datos y traerlos al Global Environment
aa <- rio::import("./datos/pruebas/gapminder.rdata")

#- (!!!!) Aunque en realidad podríamos haberlos leido directamente desde internete.
bb <- rio::import("https://raw.githubusercontent.com/jennybc/gapminder/master/data/gapminder.rdata")

#- (!!!!) A veces se pueden importar directamente y otras hace falta una conexión, p.ej. con url()
load(url("https://raw.githubusercontent.com/jennybc/gapminder/master/data/gapminder.rdata"))


# BIEN, vamos ya a practicar dplyr. Antes limpiamos Global y borramos gapminder.rdata
rm(list = ls())
fs::file_delete("./datos/pruebas/gapminder.rdata")

#- vamos a trabajar con los datos de gapminder. Sabemos descargar e importar los datos , pero ....
#- esos datos están tb en el paquete "gapminder" [ https://github.com/jennybc/gapminder ]
library(gapminder) #- paquete con el conjunto de datos gapminder

df <- gapminder  #- ¿Donde estaba gapminder?

#- Como ya tenemos los datos de gapminder en el Global, vamos ya a practicar con el paquete dplyr

#- PRIMERA FUNCIÓN de dplyr: filter() -----------------------------------------------------------------------------
#- PRIMERA FUNCIÓN de dplyr: filter() -----------------------------------------------------------------------------
#- filter() es una f. que se utiliza para seleccionar o filtrar las filas de un df

##------------------------------------------------ Filtrar filas con CONDICIONES: filter()
#- Observaciones de España (country == "Spain")
aa <- df %>% filter(country == "Spain")

#- filas con valores de "lifeExp" < 29
aa <- df %>% filter(lifeExp < 29)

#- filas con valores de "lifeExp" entre [29, 32]
aa <- df %>% filter(lifeExp >=  29 , lifeExp <= 32)
aa <- df %>% filter(lifeExp >=  29 &  lifeExp <= 32)
aa <- df %>% filter(between(lifeExp, 29, 32))

#- observaciones de paises de Africa con lifeExp > 72
aa <- df %>% filter(lifeExp > 72 & continent == "Africa")

#- observaciones de países de Africa o Asia con lifeExp > 72
aa <- df %>% filter(lifeExp > 72 &  continent %in% c("Africa", "Asia") )
aa <- df %>% filter(lifeExp > 72 & (continent == "Africa" | continent == "Asia") )


##------------------------------------------------ Filtrar filas por POSICION: slice()
#- selecciona las observaciones de la decima a la quinceava
aa <- df %>% slice(c(10:15))

#- selecciona las observaciones de la 12 a 13 Y de la 44 a 46, Y las 4 últimas
aa <- df %>% slice( c(12:14, 44:46, n()-4:n()) )           #- AQUI hay un error, tenéis  q arreglarlo.
aa <- df %>% slice( c(12:14, 44:46, nrow(df)-4:nrow(df)) ) #- esta expresión hace exactamente lo mismo
#- Pista: igual os ayuda trocear la expresión nrow(df)-4:nrow(df)
(nrow(df)-4):nrow(df)


#- SEGUNDA FUNCIÓN de dplyr: arrange() -----------------------------------------------------------------------------
#- SEGUNDA FUNCIÓN de dplyr: arrange() -----------------------------------------------------------------------------
#- arrange() es una f. que se utiliza para reordenar las filas de un df en función de los valores de las variables


#- ordena las filas de MENOR a mayor según los valores de la v. lifeExp
aa <- df %>% arrange(lifeExp)

#- ordena las filas de MAYOR a menor según los valores de la v. lifeExp
aa <- df %>% arrange(desc(lifeExp))

#- ordenada las filas de MENOR a mayor según los valores de la v. lifeExp.
#- Si hay empates se resuelve con la variable "pop"
aa <- df %>% arrange(lifeExp, pop)

##----------------------------------------------------------------------------------------------------------------- 
##- ALERTA: aquí haremos la SEGUNDA TAREA en clase para entregar
# Ejercicio 01: 

#- dplyr tiene muuuuchas funciones auxiliares; como por ejemplo: top_n() o top_frac()
#- Ejercicio 02:  




#- TERCERA FUNCIÓN de dplyr: rename() -----------------------------------------------------------------------------
#- TERCERA FUNCIÓN de dplyr: rename() -----------------------------------------------------------------------------
#- rename() es una f. que se utiliza para cambiar el nombre de las variables

##--------------------------------------------------- Renombrar las variables: rename()

#- cambia los nombres de lifeExp y gdpPercap a life_exp y gdp_percap
aa <- df %>% rename(life_exp = lifeExp,  gdp_percap = gdpPercap)

#- (!!) la función names() es muy útil. 
#- Es una f. de R-base, concretamente del paquete "base" que te devuelve un vector con los nombres de las variables
#- además se puede usar para cambiar el nombre si haces  "names(x) <- value"
names(df) 
aa <- df
names(aa) <- names(aa) %>% toupper
names(aa) <- names(aa) %>% tolower
names(aa) <- c("var_01", "var_02", "var_03", "var_04", "var_05" , "var_06")
names(aa) <- paste0("Var_", 1:6)
names(aa) <- paste0("Lag_", formatC(1:6, width = 2, flag = "0")) #- (!!!)




#- CUARTA FUNCIÓN de dplyr: select() -----------------------------------------------------------------------------
#- CUARTA FUNCIÓN de dplyr: select() -----------------------------------------------------------------------------
#- select() es una f. que se utiliza para seleccionar variables (o columnas)

#----- seleccionar variables  por NOMBRE

#- selecciono las variables year y lifeExp
aa <- df %>% select(year, lifeExp)
aa <- df %>% select(c(year, lifeExp))

my_variables <- c("year", "lifeExp")
aa <- df %>% select(my_variables)

#- selecciono todas las v. excepto "year"; osea, quitamos "year" del df
aa <- df %>% select(-year)

# quitamos year y lifeExp
aa <- df %>% select(-c(year, lifeExp))


#----- seleccionar variables  por POSICIÓN
#- seleccionamos las variables {1,2,3, 5}
aa <- df %>% select(1:3, 5)

#- quitamos las variables {1,2,3, 5}
aa <- df %>% select(- c(1:3, 5))


#----- mas posibilidades de select()

#- dejamos en aa solamente a las columnas "year" y "pop"; ADEMÁS, ahora, "pop" irá antes que "year"
aa <- df %>% select(pop, year)

#- "gdpPercap" que es la última columna pasa a ser la primera
aa <- df %>% select(gdpPercap, everything())

#(!!) otras 2 formas de hacer lo mismo: que la última columna pase a ser la primera
aa <- df %>% select( ncol(df), everything())
aa <- df %>% select( length(df), everything())



#- QUINTA FUNCIÓN de dplyr: mutate() -----------------------------------------------------------------------------
#- QUINTA FUNCIÓN de dplyr: mutate() -----------------------------------------------------------------------------
#- mutate() es una f. que se utiliza para CREAR nuevas variables

##--------------------------------------------------- CREAR nuevas variables: mutate()

#- Creamos la variable: GDP = pop*gdpperCap
aa <- df %>% mutate(GDP = pop*gdpPercap)

#- creo una columna con un valor constante e igual a 5 (?)
aa <- df %>% mutate(constante = 5)

#- creo un index (de 4 formas distintas)
aa <- df %>% mutate(indice = 1:1704)
nn <- 1704
aa <- df %>% mutate(indice = 1:nn)
aa <- df %>% mutate(indice = 1:n())  #- !!
aa <- df %>% mutate(indice = 1:nrow(df))



#- SEXTA FUNCIÓN de dplyr: summarise() -----------------------------------------------------------------------------
#- SEXTA FUNCIÓN de dplyr: summarise() -----------------------------------------------------------------------------
#- summarise() es una f. que se utiliza para CREAR "resumenes"/estadisticos de variables. Por ejemplo la media, o la varianza


#- summarise() para calcular la media global de la v. "lifeExp": retornará un df con 1 único valor 
aa <- df %>% summarise(media = mean(lifeExp))
#- (!!) si solo quieres calcular una media R-base es más fácil: retorna un vector con 1 único elemento
aa <- mean(df$lifeExp)

#- summarise() para calcular el número de filas de un df
aa <- df %>% summarise(NN = n())  #- retorna un df con un único valor: el número de filas
aa <- df %>% count()              #- count() es una f. auxiliar muy útil
aa <- df %>% count

#- summarise() para calcular la desviación típica de la v. "lifeExp"
aa <- df %>% summarise(desviacion_tipica = sd(lifeExp))

#- retornará un único valor: el máximo de la variable "pop"
aa <- df %>% summarise(max(pop))

##- summarise() para calcular varios estadisticos de una variable ----------


aa <- df %>% summarise(mean(lifeExp), sd(lifeExp)) #- #- retornará un df 2 valores: la media y sd de la v. "lifeExp"

##- summarise() para calcular 1 estadistico de varias variables ----------
#- retornará 2 valores: las medias de "lifeExp" y "gdpPercap"
aa <- df %>% summarise(mean(lifeExp), mean(gdpPercap))


#- aplicar summarise() a todas las columnas: sumarise_all() -------------------
#- media de cada una de las 6 variables. las 2 primeras son texto (en realidad son factores, lo puedes ver con str(df))
aa <- df %>% summarise_all(mean)  #- mirad la ayuda de summarise_all()  PERO no os asusteis!!
str(df)

#- media y """"sd"""" de las 6 variable. las 2 primeras son factores (*** WTF !!!!) !!!!!
aa <- df %>% summarise_all( funs(mean, mode) )


#- !! summarise_if() y summarise_at muy útiles  pero ...
aa <- df %>%  summarise_if(is.numeric, funs(mean, sd) )
aa <- df %>%  summarise_if(is.numeric, funs(mean, sd), na.rm = TRUE ) #- !!!

aa <- df %>%  summarise_at(3:5, funs(mean, sd) )
aa <- df %>%  summarise_at(vars(lifeExp, pop), funs(mean, sd), na.rm = TRUE )


#- veamos información de nuestra sesión de trabajo !!
sessionInfo()


#- SEPTIMA FUNCIÓN de dplyr: group_by() -----------------------------------------------------------------------------
#- SEPTIMA FUNCIÓN de dplyr: group_by() -----------------------------------------------------------------------------
#- group_by() es una f. que se utiliza para CREAR "dfs agrupados"


##--------------------------------------------------- agrupar/desagrupar el df en GRUPOS: group_by()

#- cogemos df y lo (des)agrupamos por grupos definidos por la variable "continent"; osea, habrá 5 grupos
#- después con summarise() calcularemos el nº de observaciones en cada continente o grupo; es decir, nos retornará un df con una fila por cada continente
aa <- df %>% group_by(continent) %>% summarise(NN = n())
aa


#- cogemos df y lo agrupamos por "continent",
#- despues calculamos 2 cosas: el numero de observaciones o rows
#- y el número de países en cada continente (NN_countries)
aa <- df %>% group_by(continent) %>%
  summarize(NN = n(), NN_countries = n_distinct(country))
aa


#- cogemos df y lo agrupamos por "continent", después calculamos la media de "lifeExp"
aa <- df %>% group_by(continent) %>%
  summarize(mean(lifeExp))
aa


#- cogemos df y filtramos para quedarnos con las observaciones de 1952
#- despues lo agrupamos por "continent",
#- despues calculamos la media de "lifeExp"
aa <- df %>% filter(year == "1952") %>%
  group_by(continent) %>%
  summarize(mean(lifeExp))
aa


#- cogemos df y filtramos (cogemos) las observaciones de 1952 y 2007
#- agrupamos por "continent",
#- despues calculamos la media de "lifeExp" y de "gdpPercap"
aa <- df %>% filter(year %in% c(1952, 2007)) %>%
  group_by(continent, year) %>%
  summarize(mean(lifeExp), mean(gdpPercap))
aa



##------- summarise_at() : la entenderemos mejor luego, un poco mas abajo

#- cogemos df y lo agrupamos por "continent" y "year", despues calculamos la media y mediana de "lifeExp" y de "gdpPercap"
aa <- df %>%
  filter(year %in% c(1952, 2007)) %>%
  group_by(continent, year) %>%
  summarise_at(vars(lifeExp, gdpPercap), funs(mean, median)  )

aa



##------- summarise_if() : la entenderemos mejor luego, un poco mas abajo

aa <- df %>%
  filter(year %in% c(1952, 2007)) %>%
  group_by(continent, year) %>%
  summarise_if(is.numeric, funs(mean, median)  )

aa



#-------------------------------------------------------------------- CUESTIONES
#-------------------------------------------------------------------- CUESTIONES
#- este tutorial se ha basado/aprovechado de este curso: http://stat545.com/block010_dplyr-end-single-table.html

# ¿En qué continente ha aumentado más la esperanza de vida?
df <- gapminder
#- primer intento: se puede hacer de una vez, pero vamos a partir el código en 2 trozos
aa <- df %>% filter(year %in% c(1952, 2007)) %>%
  group_by(continent, year) %>%
  summarize(media_anyo = mean(lifeExp)) %>% ungroup()

aa1 <- aa %>% group_by(continent) %>%
  summarise(min_l = min(media_anyo), max_l = max(media_anyo)) %>%  #- min() y max()
  mutate(dif = max_l - min_l)

#- segundo intento: se puede hacer de una vez, pero vamos a partir el código en 2 trozos
aa <- df %>% filter(year %in% c(1952, 2007)) %>%
  group_by(continent, year) %>%
  summarize(media_anyo = mean(lifeExp)) %>% ungroup()

aa1 <- aa %>% group_by(continent) %>%
  arrange(year) %>%
  mutate(variacion_esperanza = media_anyo - lag(media_anyo))  #- lag()
aa1


#- en realidad este chunk no hace lo que dice el parrafo de arriba que hace !! ¿Qué es lo que realmente hace?
aa <- df %>%
  group_by(continent, year) %>%
  select(continent, year, lifeExp) %>%
  summarise(mean_life = mean(lifeExp)) %>%
  arrange(year) %>%
  mutate(incre_mean_life_0 = mean_life - first(mean_life)) %>%
  mutate(incre_mean_life_t = mean_life - lag(mean_life)) %>%
  arrange(continent)
aa

#- variación de lifeExp en Spain año a año (bueno lustro a lustro)
aa <- df %>%
  group_by(country) %>%
  select(country, year, lifeExp) %>%
  mutate(lifeExp_gain_every_year = lifeExp - lag(lifeExp)) %>%
  filter(country == "Spain" )


#- ganancia acumulada
aa <- df %>%
  group_by(country) %>%
  select(country, year, lifeExp) %>%
  mutate(lifeExp_gain_every_year = lifeExp - lag(lifeExp)) %>%
  #--- 2 filas nuevas
  mutate(lifeExp_gain_every_year2 = if_else(is.na(lifeExp_gain_every_year), 0, lifeExp_gain_every_year)) %>%  #- if_else()
  mutate(lifeExp_gain_acumulado = cumsum(lifeExp_gain_every_year2)) %>%  #- cumsum()
  filter(country == "Spain")


#- ganancia acumulada (otra forma de hacer lo mismo)
aa <- df %>%
  group_by(country) %>%
  select(country, year, lifeExp) %>%
  mutate(lifeExp_gain_acumulada = lifeExp - lifeExp[1])  %>%
  filter(country == "Spain")


#- Obtener, para cada periodo, los (3) países de Asia con MAYOR lifeExp.  (EJERCICIO... tic-tac tic-tac). 
#- Igual podeis inspiraros en el chunk de abajo



#- Obtener, para cada periodo, los países de Asia con mayor y menor lifeExp.
aa <- df %>%
  filter(continent == "Asia") %>%
  select(year, continent, country, lifeExp) %>%
  group_by(year) %>%
  filter(min_rank(desc(lifeExp)) < 2 | min_rank(lifeExp) < 2) %>%   #- min_rank()
  arrange(year)




# A ver si entendeis este ejemplo

# (!!!) Una función auxiliar que es muy útil al utilizarla junto a mutate: case_when().
aa <- df %>%
  group_by(continent, year)  %>%
  mutate (media_lifeExp = mean(lifeExp)) %>%
  mutate (media_gdpPercap = mean(gdpPercap)) %>%
  mutate(GOOD_or_BAD = case_when(
    lifeExp > mean(lifeExp) & gdpPercap > mean(gdpPercap)  ~ "good",
    lifeExp < mean(lifeExp) & gdpPercap < mean(gdpPercap)  ~ "bad" ,
    lifeExp < mean(lifeExp) | gdpPercap < mean(gdpPercap)  ~ "medium"
  )) %>%
  filter(country == "Spain")





