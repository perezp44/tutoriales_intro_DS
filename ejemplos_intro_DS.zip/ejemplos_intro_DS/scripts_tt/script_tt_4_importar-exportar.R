#- OBJETIVO: aprender a importar y exportar datos en R

#- Podemos cargar datos que tengamos tanto en nuestro PC como en una dirección de internet.

#- Por ejemplo, hay un archivo .csv en esta dirección deinternet:
#- https://raw.githubusercontent.com/perezp44/iris_data/master/data/iris.csv
#- podemos descargarlo con 

download.file("https://raw.githubusercontent.com/perezp44/iris_data/master/data/iris.csv", 
               "./datos/pruebas/iris_descargado.csv")

#- ¿Cómo lo cargamos en memoria? ¿Como importamos ese fichero de datos en R?
#- Venga, primero lo vamos a hacer con menús ..... pero lo normal es hacerlo con instrucciones.


#- hagamos visibles dos data.frames de R: iris y mtcars  ¿donde estaban?
iris <- iris
mtcars <- mtcars


#- para cargar datos en R hay multitud de paquetes
#- los paquetes que se usan en el tidyverse son: "readr" y "haven"
#- PERO, creo que es mejor que nos centremos en el paquete "rio"
#- veamos "rio" en CRAN: https://cran.r-project.org/web/packages/rio/index.html
#- generalmente los paquetes tienen una version de desarollo en Github, veámosla: https://github.com/leeper/rio
#- bien, vamos a usar el pkg "rio"

library(rio)
help(package = "rio")   #- ayuda interna del pkg "rio"


#-------  EXPORTACION -------------------------------------------
#- vamos a exportarlos a varios formatos. la función es export(). Veamos la yuda de la f. export() apretando F1
export(iris)  #- xq no funciona?
export(iris, "./datos/pruebas/my_iris.csv")  
export(iris, "./datos/pruebas/my_iris.xlsx")  
#export(iris, "./datos/pruebas/my_iris.dta")  #- xq no funciona?  #- Borra el archivo creado xq luego dara Pb's
export(iris, "./datos/pruebas/my_iris.sav")


#- bonus: exportar 2 df en un único archivo .xlsx
export(list(iris = iris, mtcars = mtcars ), file = "./datos/pruebas/my_iris_mtcars.xlsx")

#- bonus: le añadimos un libro mas al archivo "my_iris_mtcars.xlsx"
export(iris, "./datos/pruebas/my_iris_mtcars.xlsx", which = "iris_2")



#-------  IMPORTACION -------------------------------------------
#- venga, a importar los ficheros "my_iris"
my_iris.csv <- import("./datos/pruebas/my_iris.csv")
class(my_iris.csv)

my_iris.csv <- import("./datos/pruebas/my_iris.csv", setclass = "tibble") #- como una tibble
class(my_iris.csv)


#- los de SPSS
my_iris.spss <- import("./datos/pruebas/my_iris.sav", setclass = "tibble") #- como una tibble


#- los .xlsx
my_iris_mtcars <- import("./datos/pruebas/my_iris_mtcars.xlsx") #- solo importa el primer libro
my_iris_mtcars <- import("./datos/pruebas/my_iris_mtcars.xlsx", sheet = 2) #- solo importa el segundo libro del archivo
my_iris_mtcars <- import("./datos/pruebas/my_iris_mtcars.xlsx", sheet = "iris_2") #- solo importa el libro llamado "iris_2"



#- importamos todos los libros de un archivo .xlsx
library(readxl)
my_IRIS_list <- lapply(excel_sheets("./datos/pruebas/my_iris_mtcars.xlsx"), read_excel, path = "./datos/pruebas/my_iris_mtcars.xlsx")




#- importamos todos los archivos que hemos creado en "./datos/pruebas/"
library(purrr)
my_carpeta <- "./datos/pruebas/"

lista_de_archivos <- list.files(my_carpeta)  #- Ok con base ...
lista_de_archivos <- fs::dir_ls(my_carpeta)  #- pero mejor con el pkg "fs"

my_IRIS_list_2 <- map(lista_de_archivos, import)


#---------------------------- BORRAMOS los archivos con los que hemos jugado ---------------------------
#- vamos a borrar los archivos q hemos creado:
list.files("./datos/pruebas")             #- vemos el listado de archivos en la carpeta "./datos/pruebas"
file.remove("./datos/pruebas/mtcars")     #- xq no funciona (donde está guardado mtcars?)

#- las borramos todas
# file.remove(file.path("./datos/pruebas", list.files("./datos/pruebas"))) #- con R-base

#- pero mejor con el pkg fs
my_carpeta <- "./datos/pruebas/"
lista_de_archivos <- fs::dir_ls(my_carpeta)  
fs::file_delete(lista_de_archivos)



#----------------   FORMATOS PROPIOS de R ----------------------------------------------------------
#- lo que sí hay que saber es que R tiene 2 formatos propios .rds y .RData (o .rda)

#- El formato .RData tienen la ventaja de que puedes guardar varios objetos a la vez
save(mtcars, iris,  file = "./datos/pruebas/mtcars_and_iris.RData")

#- para cargar . RData
load("./datos/pruebas/mtcars_and_iris.RData")

#- Una “desventaja” del formato RData es que al importar un fichero .RData, los objetos que contiene se cargan siempre con el nombre con el que fueron grabados.


#- guardar en formato .rds
saveRDS(iris, "./datos/pruebas/iris.rds")            #- con base-R
readr::write_rds(iris, "./datos/pruebas/iris_2.rds")   #- con pkg "readr"
rio::export(iris, "./datos/pruebas/iris_3.rds")    #- con "rio"

#- para importar .rds
iris_imp_rds <- readRDS("./datos/pruebas/iris.rds")


rm(list = ls())   #- borramos el espacio de trabajo


#- borarmos los ficheros con los que hemos jugado
my_carpeta <- "./datos/pruebas/"
lista_de_archivos <- fs::dir_ls(my_carpeta)  
fs::file_delete(lista_de_archivos)


#- FIN


#------------------------------------------------------------------------------------
#------------------------------------------------------------------------------------
#- trozos de código sacados del tutorial 4: tt_04_cargar_datos_v6

#- usando el pkg readr
library(readr)
#- exporta en formato CSV el df iris al fichero "iris.csv" 
#- Cuidado!! es una ruta absoluta. No funcionará en todos los ordenadores
write_csv(iris, path = "C:/Users/perezp/Desktop/iris.csv")

#- exporta en formato CSV el df iris al fichero "iris.csv". 
#- Como no se especifica la ruta, se grabará en el directorio de trabajo 
write_csv(iris, path = "iris.csv")


#- como trabajamos con Rprojects, el directorio de trabajo es la carpeta del propio proyecto, asi que
#- la siguiente instrucción exportará en formato .csv el df iris al fichero "iris.csv". 
#- Se guardará en la subcarpeta "datos/pruebas/" del proyecto
write_csv(iris, "./datos/pruebas/iris.csv")


#- Por una razón que igual no entenedeis del todo aún es mejor hacerlo así:
my_ruta <- paste0(here::here(), "/datos/pruebas/iris.csv" )
write_csv(iris,  my_ruta)


#- Otra vez exportamos en formato .csv el df iris. Esta vez explicitamos las opciones o parámetros de la función
write_csv(iris, path = "./datos/pruebas/iris.csv", col_names = TRUE)





#--------------------------------------- IMPORTAR datos con readr -----------------------------------
#--------------------------------------- IMPORTAR datos con readr -----------------------------------

#- importamos los datos del fichero "iris.csv" y los guardamos en un objeto que llamamos "iris_imp_csv". 
#- Recuerda que acabamos de exportar "iris" a la carpeta "/datos/pruebas/" dentro del Rproject
iris_imp_csv <- read_csv("./datos/pruebas/iris.csv")


#- Algunas opciones de read_csv() que conviene conocer: skip, na, col_names
#- Por ejemplo, el chunk que ves abajo utiliza read_csv() pero....
#- Comienza a importar datos desde la quinta columna, trata los valores -44 y $ como NAs y provee un vector con los nombres que queremos para las variables (o columnas)

mis_datos <- read_csv("./datos/pruebas/iris.csv", skip = 5, na = c("-44", "$"), col_names = c("X1", "X2", "YY", "X4", "ZZ"))


#- read_delim() es más general que read_csv(). Puedes ver el punto 3 del tt_4, concretamente en otros datos tabulares
iris_imp_csv_2 <- read_delim("./datos/pruebas/iris.csv", delim = ",")

