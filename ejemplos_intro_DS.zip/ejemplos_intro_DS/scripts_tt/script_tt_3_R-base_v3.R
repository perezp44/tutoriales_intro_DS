## Fichero con las instrucciones R del tutorial "tt_4_base-R_v3.html"
## ---- echo = FALSE-------------------------------------------------------
#library(knitr)
#library(here)
#library(tidyverse)


#-------------------- operaciones básicas con R
2 + 2
2 - 2
2 * 2
2 / 2
#--- Potenciación (se puede hacer con el operador ^ o con **)
3^2
3**2

#--- división entera y módulo
11 %/% 5    # división entera
11 %% 5     # módulo (resto de la división entera)


#------------------------------------------
6 + 2 * 5
(6 + 2) * 5


#------------------------------------------
2  + 2 + 2 + 2 + 2 +
10 +
30


## ----  ASIGNACION ----------------------------
aa <- 2 + 2
aa

aa + 1

aa <- 10

aa


aa <- 2 + 2
bb <- 5 + aa
cc <- 1 + aa * 2
dd <- bb


#---- Borrado de objetos
ls()              #- muestra los objetos en el Global env. Hace lo mismo que objects()

rm(cc)            #- borra/elimina el objeto cc del Global env.
rm(list = ls())   #- borra todos los objetos del Global env.


#------------------------------------------ nombres válidos
# pepe <- 4
# pepe_2 <- 4
# pepe_2.3 <- 22
# .hola <- 7
#
#------------------------------ nombres NO válidos
# .2xx <- 88
# _hola <- 66


## --------------------------------------------  nombres reservados
## if  else repeat  while  for in next break
## function
## TRUE FALSE
## NULL Inf NaN
## NA NA_integer_ NA_real_ NA_complex_ NA_character_


## ------------------------------------------------------------------------
aa <- "La calle en la que vivo es"    #- texto
bb <- 4L                              #- número entero
cc <- 4.3                             #- número decimal
dd <- TRUE                            #- logical
## ------------------------------------------------------------------------
typeof(aa)
typeof(bb)
typeof(cc)
typeof(dd)





## ------------------------------------------------------------------------  COMPARACIONES
2 < 4    # MENOR que: esta expresión chequea si 2 es MENOR que cuatro. Como es cierto, nos devuelve un TRUE
2 > 4    # MAYOR que: esta expresión chequea si 2 es MAYOR que cuatro. Como es cierto, nos devuelve un TRUE
5 >= 7   # MAYOR o IGUAL que.
8 <= 8   # MENOR o IGUAL que.
9 == 7   # IGUAL a: como 9 no es igual a 7, nos devolverá un FALSE
2 == 2   # IGUAL a: como 2 es igual a 2, nos devuelve TRUE
2 != 4   # NO IGUAL: como 2 no es igual a 4 nos devuelve TRUE
5 != 5   # NO IGUAL: como 5 es igual a 5, nos devuelve FALSE


## ------------------------------------------------------------------------
aa <- "Mi nombre es"
bb <- "Pedro"
paste(aa, bb)
paste(aa, bb, sep = " ... ")
# Prueba tú mismo que hace la función paste0()




## ------------------------------------------------------------------------
toupper(aa)
tolower(aa)
nchar(bb)                    #- nchar() nos devuelve el número de caracteres de un string
substring(bb, 2, nchar(bb))  #- substring() extrae caracteres de un string


## ------------------------------------------------------------------------
(4 > 3) & (3 < 2)     #- Y: como se cumplen las dos condiciones nos devuelve TRUE
(1==2) | (2 >3)       #- O: Como no se cumple ninguna de las 2 condiciones nos devuelve FALSE
!(4 > 3)              #- NOT: 4 es mayor que 3 es TRUE, pero el ! delante de esa condición la niega y pasa a FALSE
!!(4 > 3)             #- si niegas dos veces, vuelves al ppio. TRUE

xor(10 < 1, 10 >1 ) #- se cumple 1 de las dos condiciones, entonces TRUE
xor(10 > 1, 10 >1 ) #- se cumplen las 2 condiones, entonces FALSE
xor(10 < 1, 10 <1 ) #- no se cumple ninguna de las 2 condiciones: FALSE







#------------- Aprendiendo como "funcionan" las funciones
sqrt(9)

sqrt(9, 4)   # no funciona porque sqrt() solo admite un argumento
sqrt("9")    # no funciona, solo hemos puesto un argumento pero es textual, y ha de ser númerico

help(sqrt)


sqrt(x = 9)
sqrt(x = 4)


sqrt(9)
sqrt(4)

#- diferenciando el nombre y valor de un argumento
x <- 25
sqrt(9)
sqrt(x)
sqrt(x = x)


#----- vemos otra funcion : log
help(log)
log(1000, base = 10)


log(1000)  #- como no especificamos el valor del argumento "base", R lo fija por defecto base = exp(1) y toma logaritmos naturales

log(1000, base = 10) #- ahora si estamos calculando logaritmo en base 10

#- partial matching
log(1000, bas = 10)  #- funciona, pero ...
log(1000, 10)         #- esto sí es muy habitual verlo

#- si no pones el nombre de los argumentos, cuidado con el orden de los argumentos
log(10, 1000)



## ------------------------------------ secuencias. Intenta entender como funciona la f. seq()
seq(0, 10)
seq(0, 10, 2.5)
seq(0, 10, length.out = 3)


#- tb podemos ver cuantos argumentos tiene una función con la f. args()
args(sqrt)       #- sqrt() solo tiene un argumento, x
args(log)        #- log() tiene 2 argumentos: x y base. Además base tiene un valor por defecto: exp(1)
args(args)       #- args() solo tiene un argumento, llamado name.





#------------------------------------------------------------------------  Nuestro primer vector
aa <- c(3, 22, 6)
aa

is.vector(aa)


typeof(aa)


#------------------------------------------- vector de texto
aa <- c("Hola", "número", "9")
is.vector(aa)
typeof(aa)


## ------------------------------------------------------------------------ ¿de que tipo será el vector?
aa <- c(4, 6, "Hola")
is.vector(aa)
typeof(aa)
aa


## ------------------------------------------------------------------------
aa <- c(TRUE, 4L, 4, "Hola")
typeof(aa)
aa <- c(TRUE, 4L, 4)
typeof(aa)
aa <- c(TRUE, 4L)
typeof(aa)


## ------------------------------------------------------------------------
aa <- c(1:4)
aa
aa <- as.character(aa)
aa


## ------------------------------------------------------------------------ los vectores pueden tener atributos
aa <- c(1:10)
typeof(aa)
length(aa)
attributes(aa)


## ------------------------------------------------------------------------
aa <- c(1:3)
attributes(aa)
attr(aa, "atributo_1") <- "This is a vector"
attributes(aa)
attr(aa, "atributo_2") <- c("primero", "segundo", "tercero")
aa


## ------------------------------------------------------------------------
aa <- c(a = 1, b = 2, c = 4)


## ------------------------------------------------------------------------
aa <- c(1,2,4)
aa <- setNames(aa, letters[1:3])
aa


## ------------------------------------------------------------------------
aa <- c(1,2,4)
aa <- set_names(aa, c("a", "b", "c"))
aa


## ------------------------------------------------------------------------
aa <- c(10:1)
aa[c(1:2)]        #- primer y segundo elemnto del vector
aa[c(1,2,9,10)]   #- dos primeros y 2 ultimos
aa[c(1,1,10,10)]  #- si repites el indice se repite el elemento del vector


## ------------------------------------------------------------------------
aa <- c(10:1)
aa[- c(1,2, 9:10)]


## ------------------------------------------------------------------------
aa <- 1:10
aa <- aa[aa >= 7]
aa


## ---- eval = FALSE-------------------------------------------------------
## aa <- 1:10
## aa <= 4
## aa[aa <= 4]
## aa <- aa[aa <= 4]


## ------------------------------------------------------------------------
aa <- c(1:10)
aa[4] <- 88    #- el segundo elemnto de aa tomara el valor 88
aa <- c(aa, 111, 112) #- añadimos 2 elementos al vector aa


## ------------------------------------------------------------------------
aa <- c(1:5)
bb <- c(100:105)
cc <- c(aa, bb)


## ------------------------------------------------------------------------
aa <- 1:10
bb <- 1:10
aa + bb


## ------------------------------------------------------------------------
aa <- 1:10
aa + 1


## ------------------------------------------------------------------------
aa <- 1:6
bb <- 1:2
aa + bb


## ------------------------------------------------------------------------
aa <- c(4, 9, 25)
sqrt(aa)


## ------------------------------------------------------------------------
aa <- 1:3
bb <- 3:1

aa == bb
aa >= bb
aa != bb


## ------------------------------------------------------------------------
aa <- 1:3
bb <- 2

aa == bb
aa >= bb
aa != bb


## ------------------------------------------------------------------------
aa <- 1:4
bb <- c(1:2, 99)

union(aa, bb)
intersect(aa, bb)

setdiff(aa, bb)       #- Elementos de aa que no estan en bb
setequal(aa,bb)       #- chequea si dos vectores son iguales
setequal(1:4, 1:4)    #- chequea si dos vectores son iguales



## ------------------------------------------------------------------------
aa <- 1:4
length(aa)


## ------------------------------------------------------------------------
aa <- 1:4
sum(aa)


## ------------------------------------------------------------------------
aa <- 1:4
cumsum(aa)


## ------------------------------------------------------------------------
aa <- 1:4
mean(aa)


## ------------------------------------------------------------------------
aa <- c(2, 1, 4, 3)
sort(aa)


## ------------------------------------------------------------------------
aa <- c(20, 10, 7, 30)
order(aa)


## ------------------------------------------------------------------------
(aa <- matrix(1:6, ncol = 2, nrow = 3))


## ------------------------------------------------------------------------
aa <- c(1:3)
bb <- c(11:13)
cc <- cbind(aa, bb)  #- agrupamos los vectores por columnas con cbind()
dd <- rbind(aa, bb)  #- agrupamos los vectores por filas con rbinb()


## ---- eval = FALSE-------------------------------------------------------
## aa <- matrix(1:9, nrow = 3, ncol = 3) #- cramos una matriz 3x3
##
## bb <- aa[2, 3]          #- seleccionamos el elemento (2,3) de la matriz
##
## bb <- aa[ , 2]          #- selecionamos la segunda columna (devuelve un vector)
## bb <- aa[ , c(2,3)]     #- selecionamos la segunda y tercera columna
## bb <- aa[c(2,3), ]      #- selecionamos la segunda y tercera FILAS
##
## bb <- aa[-2, ]          #- eliminamos la segunda fila
## bb <- aa[-2, -c(1,2)]   #- eliminamos la segunda fila y la primera y segunda Columnas


## ------------------------------------------------------------------------
aa <- matrix(1:6, nrow = 2, ncol = 3) #- cramos una matriz 2x3

colnames(aa) <- c("col_1", "col_2", "col_3")
rownames(aa) <- paste("fila", 1:2,sep = "_")
aa


## ---- eval = FALSE-------------------------------------------------------
## aa <- matrix(1:6, nrow = 3, ncol = 2)  #- matriz 3x2
## dim(aa)  #- devuelve un vector con las dimensiones de la matriz
## t(aa)    #- transpone la matriz


## ------------------------------------------------------------------------
(aa <- array(1:12, c(2, 3, 2)) )


## ------------------------------------------------------------------------
aa <- c("lunes", "martes", "jueves", "lunes", "martes")


## ------------------------------------------------------------------------
aa_factor <- as.factor(aa)
aa_factor
is.factor(aa_factor)


## ------------------------------------------------------------------------
aa_factor_2 <- factor(aa, levels = c("lunes", "martes", "jueves"))
aa_factor_2


## ------------------------------------------------------------------------
aa_factor_2 <- factor(aa, levels = c("lunes", "martes", "jueves"))
attributes(aa_factor_2)
typeof(aa_factor_2)     #- internamente lo almacena como enteros !!


## ------------------------------------------------------------------------
attributes(x)


## ------------------------------------------------------------------------
# defino 3 vectores y una matriz
vec_numerico <- c(1:8)
vec_character <- c("Pedro", "Rebeca", "Susana")
vec_logic <- c(TRUE, FALSE, TRUE)
matriz <- matrix(1:6, nrow = 2, ncol = 3)

# creo una lista con cuatro elementos
my_list <- list(vec_numerico, vec_character, vec_logic, matriz)
my_list


## ------------------------------------------------------------------------
my_list <- list(slot_1 = vec_numerico, slot_2 = vec_character, slot_3 = vec_logic, slot_4 =matriz)
my_list


## ------------------------------------------------------------------------
length(my_list) #- nuestra lista tiene 4 slots, 4 elementos


## ------------------------------------------------------------------------
my_list_2 <- list(primer_slot = c(44:47), segundo_slot = my_list)
my_list_2


## ------------------------------------------------------------------------
my_list[2]  #- seleccionamos el segundo elemento de la lista. Nos devuelve una lista con un solo slot


## ------------------------------------------------------------------------
my_list[c(2,3)]  #- seleccionamos el segundo y tercer elemento de la lista. Nos devuelve una lista con dos slots


## ------------------------------------------------------------------------
my_list["slot_2"]  #- seleccionamos el segundo elemento de la lista. Nos devuelve una lista con un solo slot
my_list[c("slot_2", "slot_3")]  #- seleccionamos el segundo y tercer elemento de la lista. Nos devuelve una lista con dos slots


## ------------------------------------------------------------------------
my_list[[2]]  #- seleccionamos el segundo elemento de la lista. Nos devuelve el elementoq ue hay en el segundo slot; es decir un vector, vec_character


## ------------------------------------------------------------------------
my_list$slot_4  #- seleccionamos el cuarto elemento de la lista, cuyo nombre es `slot_4`; es decir, nos devuelve una matriz.


## ------------------------------------------------------------------------
my_list[["slot_4"]]  #- seleccionamos el cuarto elemento de la lista, cuyo nombre es `slot_4`; es decir, nos devuelve una matriz.



## ------------------------------------------------------------------------
my_list_2 <- list(primer_slot = c(44:47), segundo_slot = my_list)
my_list_2


## ------------------------------------------------------------------------
my_list_2[[2]][[4]]
my_list_2$segundo_slot$slot_4


## ------------------------------------------------------------------------
aa <- c(4, 8, 6, 3)
bb <- c("Juan", "Paz", "Adrian", "Marquitos")
cc <- c(FALSE, TRUE, TRUE, FALSE)
df <- data.frame(aa, bb, cc)
df


## ------------------------------------------------------------------------
df <- data.frame(Nota = aa, Nombre = bb, Aprobado = cc)
names(df)  #- con names() podemos ver los nombres de las variables del df


## ------------------------------------------------------------------------
(names(df) <- c("Grade", "Name", "Pass"))


## ------------------------------------------------------------------------
df_s <- df[,1]       #- seleccionamos la primera columna. devuelve un vector !!!
df_s <- df[,c(2,3)]  #- seleccionamos la segunda y tercera columna. devuelve un df
df_s <- df[1, ]      #- seleccionamos primera fila de todas las variables. devuelve un df. ¿xq no devuelve un vector? Preguntad si no lo sabeis
df_s <- df[c(1,4), ]  #- seleccionamos primera y cuarta fila. devuelve un df
df_s <- df[2, 3]      #- seleccionamos segunda observación de la tercera variable. Devuelve un vector.


## ------------------------------------------------------------------------
df_s <- df[3]        #- devuelve un df. Good!!
df_s <- df[c(1,2)]

#- tambien se puede hacer por nombre
df_s <- df["Name"]                #- devuelve un df
df_s <- df[c("Name", "Grade")]


## ------------------------------------------------------------------------
df_s <- df[[2]]   #- Extraemos la segunda columna. Devuelve un vector, concretamente un factor. Ahhhh!!!!!


## ------------------------------------------------------------------------
df_s <- df$Name   #- Extraemos la columna con nombre "Name". Devuelve un vector, concretamente un factor. Ahhhh!!!!!
df_s <- df$Grade  #- Extreamos la columna con nombre "Grade". Devuelve un vector numérico


## ------------------------------------------------------------------------
df_s <- df[df$Grade >= 5, ]   #- selecciono filas que cumplan que el valor de la columna grade sea >= a 5
df_s <- df[!df$Grade >= 5, ]  #- los que NO han sacado igual o mas  de 5
df_s <- df[df$Grade == 8 | df$Grade < 5, ]  #- los que han sacado exactamente 8 ó menos de 5


## ------------------------------------------------------------------------
names(df)    #- devuelve un vector con los nombre de las columnas/variables del df
nrow(df)     #- devuelve el nº de filas
ncol(df)     #- nº de columnas
length(df)   #- la longitud de las columnas/vectores que componen el df; osea devuelve otra vez el nº de filas


## ------------------------------------------------------------------------
aa <- 101:104
df$new_v <- aa


## ------------------------------------------------------------------------
df_new <- cbind(df, aa)


## ------------------------------------------------------------------------
aa <- 1:5
df_new <- as.data.frame(aa)  #- df con una sola columna


## ------------------------------------------------------------------------
summary(df)


## ------------------------------------------------------------------------
?`%in%`  #- para ver la ayuda del operador
1:10 %in% c(1,3,5,9)


## ------------------------------------------------------------------------
str(iris)


## ------------------------------------------------------------------------
c()
sum(2, 2, NULL)
mean(c(2 ,4, NULL))


## ------------------------------------------------------------------------
sum(2, 2, NA)
mean(c(2 ,4, NA))
mean(c(2, 4, NA), na.rm = TRUE)


## ------------------------------------------------------------------------
0/0
sum(2, 2, NaN)
mean(c(2 ,4, 0/0))


## ------------------------------------------------------------------------
1/0
-1/0
sum(2, 2, Inf)


## ------------------------------------------------------------------------
1:3
c(1:4)
-2:3
4:-1


## ------------------------------------------------------------------------
seq(from = 0, to = 5, by = 1)
seq(-5, 5, 2)

seq(0, 1, length.out = 3)
seq(0, 1, length.out = 5)
seq(0, 1, 5)


## ------------------------------------------------------------------------
rep(2, times= 3)
rep(1:3, 2)
rep(1:3, each = 2)       # not the same.
rep(1:3, times = 3, each = 2)
rep(1:2, length.out = 9)



## ------------------------- eliminando solo algunos objetos
aa <- 1
bb <- 2
cc <- 3
dd <- 4
quiero_dejar_estos <- c("cc", "dd")               #- fijate que estan como texto

rm(list= ls()[!(ls() %in% quiero_dejar_estos)])   #- remueve todo excepto quiero_dejar_estos

