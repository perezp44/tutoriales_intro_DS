#- TUTORIAL 6: ggplot2

library(tidyverse)

## 2. Ideas básicas sobre ggplot2 -----------------------------------------------------

## ---- primer gráfico
ggplot(iris, aes(Sepal.Length, Petal.Length, color = Species)) + geom_point()


## ---- un ggplot "realmente" es una lista
my_grafico <- ggplot()


## ---- los gráficos ggplot se incian con la f. ggplot() y unos datos
ggplot(data = iris)
ggplot(iris)


## ---- asociamos/mapeamos la v. Sepal.Length al eje x ( a la característica estética eje X) y la v. Petal.Length al eje Y
ggplot(iris, aes(x = Sepal.Length,  y = Petal.Length))

ggplot(iris, aes(Sepal.Length, Petal.Length))           #- no hace falta poner el nombre de los argumentos, pero cuidado con el orden de estos.


## ---- cuando le decimos que geometria queremos usar es cuando se visualiza el gráfico
ggplot(iris, aes(Sepal.Length, Petal.Length)) + geom_point()


## ---- las geometria tienen muchas opciones
ggplot(iris, aes(Sepal.Length, Petal.Length)) + geom_point(color = "red", size = 2, alpha = 0.2)


## ---- otra geometria geom_line()
ggplot(iris, aes(Sepal.Length, Petal.Length)) + geom_line()


## ---- se pueden añadir varias geometrías
ggplot(iris, aes(Sepal.Length, Petal.Length)) + geom_point() + geom_line()

ggplot(iris, aes(Sepal.Length, Petal.Length)) + geom_point() + geom_smooth()


## ---- asociemos con aes() una nueva variable a una caracteristica estetica, concretamente la v. Species a la estetica "color" o a "size", o a "shape"
ggplot(iris, aes(Sepal.Length, Petal.Length, color = Species)) + geom_point() 

ggplot(iris, aes(Sepal.Length, Petal.Length, size = Species)) + geom_point()  #- no tiene mucho sentido asociar Species a "size"

ggplot(iris, aes(Sepal.Length, Petal.Length, shape = Species)) + geom_point() 


## ---- mira la diferencia entre estos 2 gráficos
ggplot(iris, aes(Sepal.Length, Petal.Length))                  + geom_point()
ggplot(iris, aes(Sepal.Length, Petal.Length, color = Species)) + geom_point() 



## 2. Ideas básicas sobre ggplot2: más ideas sobre ggplot2 ---------------------------------------------

#- en realidad un gráfico ggplot2 se hace por capas, cada capa se especifica con una función de la familia geom_xx(), así que en realidad los datos y las aes() se “deberían” especificar dentro de la función geom_xx()`

## ---- 3 formas de hacer el mismo gráfico
ggplot(iris, aes(Sepal.Length, Petal.Length)) + geom_point()

ggplot(iris) + geom_point(aes(Sepal.Length, Petal.Length))

ggplot() + geom_point(data = iris, aes(Sepal.Length, Petal.Length))     #- como ves cada geom puede tener su propio df, variables etc...


## ---- como ves cada geom puede tener su propio df, variables etc...
## ---- profundicemos en esta idea
ggplot(iris, aes(Sepal.Length, Petal.Length, color = Species)) + geom_point() + geom_smooth()

ggplot(iris, aes(Sepal.Length, Petal.Length)) + geom_point(aes(color = Species)) + geom_smooth()

ggplot(iris, aes(Sepal.Length, Petal.Length)) + geom_point() + geom_smooth(aes(color = Species))


## ----  xq no funcionan estos gráfico?
ggplot(iris) + geom_point(aes(Sepal.Length, Petal.Length)) + geom_smooth(aes(color = Species))

ggplot() + geom_point(data = iris, aes(Sepal.Length, Petal.Length)) + geom_line(aes(Sepal.Length, Petal.Length))

ggplot(aes(Sepal.Length, Petal.Length)) + geom_point(data = iris) + geom_line()  #- no lo haremos en clase (!!)
 
ggplot() + geom_point(data = iris, aes(Sepal.Length, Petal.Length)) + geom_line()  #- este si funciona, pero ... no diduja las lineas


## ----  profundizando en la idea: que geom_smooth se calcule solo con los lirios de las clases versicolor y virginica. 
#- Muestro 2 formas de hacerlo
iris2 <- iris %>% filter(Species != "setosa") #- me quedo con los lirios que NO son de clase "setosa"

ggplot() + geom_point(data = iris, aes(Sepal.Length, Petal.Length, color = Species)) + geom_smooth(data = iris2, aes(Sepal.Length, Petal.Length) )

ggplot(iris, aes(Sepal.Length, Petal.Length)) + geom_point(aes(color = Species)) + geom_smooth(data = iris2)


## ---- otras formas de hacer algo parecido (!!)
iris_setosa <- iris %>% filter(Species == "setosa") #- me quedo con los lirios pequeños, los de clase "setosa"


ggplot(iris, aes(Sepal.Length, Petal.Length)) + 
  geom_point() + 
  geom_point(data = iris_setosa, aes(color = Species)) +
  geom_smooth(data = iris2,aes(Sepal.Length, Petal.Length) )


iris_solo_2_clases <- iris %>% mutate(Species_2 = ifelse(Species %in% c("versicolor", "virginica"), "versi_virgi", "setosa"))

ggplot(iris, aes(Sepal.Length, Petal.Length)) + 
  geom_point() + 
  geom_point(data = iris_setosa, aes(color = Species)) + 
  geom_smooth(data = iris_solo_2_clases, aes(Sepal.Length, Petal.Length, color = Species_2) )
 
ggplot(iris_solo_2_clases, aes(Sepal.Length, Petal.Length, color = Species_2)) + geom_point() + geom_smooth()

ggplot(iris_solo_2_clases, aes(Sepal.Length, Petal.Length, color = Species_2)) + geom_point() + geom_smooth()


## ---- este es para practicar vosotros (!!)
ggplot(iris, aes(Sepal.Length, Petal.Length)) + geom_point() + geom_smooth()
ggplot(iris, aes(Sepal.Length, Petal.Length, color = Species)) + geom_point() + geom_smooth()
ggplot(iris, aes(Sepal.Length, Petal.Length, color = Species)) + geom_point(color = "purple") + geom_smooth()

ggplot(iris, aes(Sepal.Length, Petal.Length, color = Species)) + geom_point() + geom_smooth(color = "brown")
ggplot(iris, aes(Sepal.Length, Petal.Length)) + geom_point() + geom_smooth(aes(color = Species))
ggplot(iris) + geom_point(aes(Sepal.Length, Petal.Length, color = Species) ) + geom_smooth(aes(Sepal.Length, Petal.Length, color = Species))



## 2. 3. Elementos de un ggplot -----------------------------------------------------


## ----- creemos un gráfico base
p <- ggplot(iris, aes(Sepal.Length, Petal.Length, color = Species)) + geom_point()
p


## ------ 3.1  TITULOs etc...
p + labs(title = "Gráfico 1: Longitud del sépalo frente al pétalo",
       subtitle = "(diferenciando por especie de lirio)",
       caption = "Datos provenientes del Iris dataset",
       x = "Longitud del sépalo",
       y = "Longitud del pétalo",
       color = "Especie de lirio")


## ------ borrando títulos
p + labs(color = NULL, x = NULL)  #- borra el título de la leyenda y del eje X
p + xlab(NULL) + ylab(NULL)       #- elimina títulos de los ejes X e Y


## ---- 3.2 THEMES
p + theme_gray()   #- tema por defecto
p + theme_light()
p + theme_dark()
p + theme_classic()
p + theme_minimal()
p + theme_void()




## ---- más THEMES
library(ggthemes)
p + theme_economist()
p + theme_fivethirtyeight()
p + theme_stata()
p + theme_solarized()
p + theme_excel()
p + theme_excel_new()



## ---- Puedes crear o tunear tu theme
# define custom theme
my_theme <- theme(axis.text.x = 
                  element_text(colour = "grey20", size = 12, angle = 90, hjust = 0.5, vjust = 0.5) , 
                  axis.text.y = element_text(colour = "grey20", size = 12) ,
                  text = element_text(size = 16))
p + my_theme


## ---- se puede fijar un tema por defecto con theme_set()
theme_set(theme_minimal())  #- un tema concreto
theme_set(theme_minimal() +
          theme(axis.text.x=element_blank(), axis.ticks.x=element_blank())) #- un tema modificando algunas opciones, que el eje x no muestre ticks ni escalas


## ---- volvemos al theme habitual 
theme_set(theme_gray())


## ---- Alguna opciones más del theme
p + theme(legend.position = "none")            #- que no aparezca leyenda
p + theme(legend.position = "bottom")          #- leyenda abajo
p + theme(legend.direction = "horizontal")     #- leyenda horizontal!!
p + theme(legend.title = element_text(size = 22))     #- título de la leyenda a 22
p + theme(legend.key.size = unit(2.4, "cm"))          #- tamaño de los cuadros de la leyenda

p + theme(text = element_text(size = 20, face = "bold"))         #- cambiar el tamaño de todos los elementos de texto
p + theme(text = element_text(face = "bold"))                    #- pone en negrita todos los elementos de texto

p + theme(axis.text.x = element_text(colour = "pink", size = 12, angle = 90, hjust = 0.5, vjust = 0.5)) # apariencia de la escala del eje x

p + theme(axis.title.y = element_text(size=25, angle = 45)) #- tamaño y angulo del texto del eje Y

p + theme(plot.subtitle = element_text(hjust = 3))   #- posición horizontal del subtitulo (si lo tuviese)
 
p + theme(plot.caption = element_text(hjust = 3))    #- posición vertical del pie de gráfico (si lo tuviese)
 
p + theme(panel.background = element_rect(fill = "green", colour = "pink", linetype = "longdash", size = 3.5))
p + theme(panel.background = element_blank())
p + theme(panel.background = NULL)

 
p + theme(plot.background = element_rect(fill = "pink", colour = "purple", linetype = "dotted", size = 7))


##-- 8. ASISTENTES para ggplot2

#- como podeis imaginar esto es complicadillo de memorizar ... así que vamos  aprobar un poco el paquete ggThemeAssist
# install.packages("ggThemeAssist")
library(ggThemeAssist)

p

## ---- los colores disponibles
aa <- as.data.frame(colours())


#- ya que estamos con los asistentes vamos a ver un nuevo paquete, 
#- el paquete "esquisse" que permite crear gráficos ggplot desde cero con una interfaz gráfica.
# install.packages("esquisse")
library(esquisse)
iris99 <- iris




## ---- 3.3 SMALL MULTIPLES o facetting
#p + facet_grid( . ~ Species)                # old sintaxis
p + facet_grid(cols = vars(Species))         # gráficos x columnas, separando por valores de 'Species'

p + facet_grid(rows = vars(Species))         # gráficos x filas

p + facet_wrap(vars(Species), nrow = 2, ncol = 2)        # graf x filas y columnas

## --- vamos a crear una nueva variable (por encima y por debajo de la media)
iris <- iris %>% mutate(new_variable = ntile(Petal.Width, 2)) 

iris$new_variable_2 <- cut(iris$Petal.Width,                      #- hacemos lo mismo pero con R-base cut()
                   breaks = c(-Inf, mean(iris$Petal.Width), Inf), 
                   labels = c("debajo-media", "arriba-media"))
str(iris)

## ---- ahora creamos un small multiple con esa nueva variable new_variable_2
ggplot(iris) + geom_point( aes(Sepal.Length, Petal.Length, color = Species)) +
facet_grid(rows = vars(new_variable_2), cols = vars(Species))        # graf x filas y columnas

ggplot(iris) + geom_point( aes(Sepal.Length, Petal.Length, color = Species)) +
facet_grid(new_variable_2 ~ Species)     #- el mismo gráfico pero con diferente sintaxis


#- las escalas de los smalls multiples
p + facet_grid(rows = vars(Species))                    #- escalas comunes
p + facet_grid(rows = vars(Species), scales = "free")   #- las escalas de cada small pueden variar
p + facet_grid(rows = vars(Species), scales = "free_y") #- solo dejamos libre/variar la escala del eje y

## ---- margins es útil
p + facet_grid(rows = vars(Species),  margins = TRUE)   


## ---- 3.4 Anotaciones -----------------------------------------------------------------------
p <- ggplot(iris, aes(Sepal.Length, Petal.Length, color = Species)) + geom_point()


#- annotate()
p + annotate(geom = "text", x = 6, y = 2, label = "Una anotación", size = 5) +
    annotate("rect", xmin = 6, xmax = 7,ymin = -Inf, ymax = Inf, alpha = 0.2, fill = "pink") + 
    annotate("segment", x = 5, xend = 7, y = 6, yend = 8, colour = "blue") 


#- geom_text()
p + geom_text(aes(label = Species))

p + geom_text(aes(label = Petal.Length))   #- mira la ayuda geom_label()

#- fijaros que geom_text() tiene como todos los geoms_xx() un argumento que es "data" y eso da mucha flexibilidad para hacer anotaciones

iris_x <- iris[c(45, 140),] #- seleccionamos el lirio 45 y el 140 (con R-base!!)
p + geom_text(data = iris_x, aes(label = Species), color = "black", size = 5)


#- algunas veces puede interesar añadir lineas a nuestro gráfico
p + geom_vline(xintercept = 6)
p + geom_hline(yintercept = 5, size = 1.7, colour = "black", linetype = "dashed")
p + geom_abline(intercept = 0.7, slope = 0.4, size = 2)


## ---- 3.5 Cambiando los límites de los ejes -------------------------------------------------------------
## ---- 3.5 Cambiando los límites de los ejes -------------------------------------------------------------

p <- ggplot(iris, aes(Sepal.Length, Petal.Length, color = Species)) + geom_point()

p + xlim(c (4, 6)) + ylim(c(NA, 5))  #- NA hace que ese limite lo fije automaticamente ggplot2.
                                      
p + xlim(c (7, 3)) + ylim(c(NA, 5))  #- (!?)

p + lims(color = c("setosa"), x = c(NA,6), y = c(1,8))  #- funciona para todas las esteticas/variables p.ej: con color


#- cuidado con lims  se pueden borrar observaciones
p + geom_smooth(color = "purple")
p + geom_smooth(color = "purple") + xlim(c(4, 5.7)) + ylim(c(1.5, 5))   # deletes points

#- si no quieres que se borren coord_cartesian()
p + geom_smooth(color = "purple") + coord_cartesian(xlim = c(4, 5.7), ylim = c(1.5, 5))


## ---- 3.6 Escalas ---------------------------------------------------------------------------------------
## ---- 3.6 Escalas ---------------------------------------------------------------------------------------

#- estas 2 expresiones hacen exactamente lo mismo:
p <- ggplot(iris, aes(Sepal.Length, Petal.Length)) +  geom_point(aes (color = Species)) 

p <- ggplot(iris, aes(Sepal.Length, Petal.Length)) +   geom_point(aes (color = Species)) +
            scale_x_continuous() +
            scale_y_continuous() +
            scale_color_discrete()

#- juguemos con las escalas:
p + scale_y_reverse() + scale_colour_grey()
p + scale_x_sqrt() + scale_y_log10()
p + scale_x_continuous(trans = "log")
p + scale_color_brewer(palette = "Dark2") #- útil


#- Labels de los ejes: También se pueden modificar lo que vemos en los escalas. Antes vamos a modificar los títulos de los ejes y leyendas.
p <- p + labs(x = "Eje X", y = "Eje Y", color = "Leyenda\n para el color")

p + scale_x_continuous(breaks = seq(3, 10, 0.5), limits = c(3, 10)) 

p + scale_y_continuous(breaks = seq(0, 12, 0.25),  label = scales::dollar) 

p + scale_color_manual(values = c("purple", "pink", "red2"), name = "Especies\n de lirios")


## ---- 3.7 Transformaciones estadísticas -----------------------------------------------------------------
## ---- 3.7 Transformaciones estadísticas -----------------------------------------------------------------

#- estas dos expresiones son equivalentes
ggplot(iris, aes(Petal.Length, Sepal.Length)) + geom_point()
ggplot(iris, aes(Petal.Length, Sepal.Length)) + geom_point(stat = "identity")

ggplot(iris, aes(Petal.Length, Sepal.Length)) + geom_point(stat = "unique") #- dejaría solo observaciones no repetidas


p <- ggplot(iris, aes(Petal.Length, Sepal.Length, color = Species))
 
p + geom_point(stat = "identity")

p + geom_point(stat = "smooth", method = "auto")


#- geom_xx vs. stats_xx
p + geom_point() + geom_smooth()
p + geom_point() + stat_smooth()
 
p + geom_point() + stat_smooth(method = "lm",   se = FALSE,  size = 1)
p + geom_point() + geom_smooth(method = "lm",   se = FALSE,  size = 1)
 
p + geom_point() + geom_smooth(method = "lm", col = "#C42126",  se = FALSE,  size = 1)


#- un ejemplo uso que requiere usar el argumento stat
ggplot(iris, aes(Species, Sepal.Length)) + 
  geom_boxplot() + 
  geom_point(stat = "summary", fun.y = "mean", colour = "red", size = 4)
#- podriamos hacer lo mismo así: 
ggplot(iris, aes(Species, Sepal.Length)) +
  geom_boxplot() +
  stat_summary(geom = "point", fun.y = "mean", colour = "red", size = 4)


#- Otro ejemplo: el default stat de geom_histogram es stat = “bin”, mostrandonos el número de observaciones en cada bin. Si queremos que nos muestre frecuencias relatívas al grupo o bin más numeroso
ggplot(iris, aes(Sepal.Length)) + geom_histogram()

ggplot(iris, aes(Sepal.Length)) + geom_histogram(aes(y = stat(count / max(count))))




#- Bonus: Con stat_function() podemos dibujar curvas de densidad:
df <- tibble(x = c(-20, 20))
ggplot(df, aes(x = x)) +
   stat_function(fun = dnorm, args = list(mean = 0, sd = 5), color = "black") +
   stat_function(fun = dnorm, args = list(mean = 0, sd = 1), color = "red") +
   stat_function(fun = dnorm, args = list(mean = 0, sd = 3), color = "blue")




## ---- 3.8 Position adjustments --------------------------------------------------------------------------
## ---- 3.8 Position adjustments --------------------------------------------------------------------------


ggplot(iris , aes(Species)) + geom_bar()
ggplot(mtcars, aes(cyl)) +  geom_bar()  #- mejor con los datos de mtcars



ggplot(mtcars, aes(factor(cyl), fill = factor(vs))) + geom_bar() #- pos
ggplot(mtcars, aes(factor(cyl), fill = factor(vs))) + geom_bar(position = "fill")
ggplot(mtcars, aes(factor(cyl), fill = factor(vs))) + geom_bar(position = "dodge")
ggplot(mtcars, aes(factor(cyl), fill = factor(vs))) + geom_bar(position = position_dodge2(preserve = "single"))



#- otro ejemplo en el que la posición es importante
ggplot(iris, aes(Sepal.Length, Petal.Length)) + geom_point() + geom_point(position = "jitter", color = "pink")
ggplot(iris, aes(Sepal.Length, Petal.Length)) + geom_point() + geom_jitter( color = "pink")



## ---- 3.9 Coordenadas -----------------------------------------------------------------------------------
## ---- 3.9 Coordenadas -----------------------------------------------------------------------------------

p <- ggplot(iris, aes(Sepal.Length, Petal.Length)) + geom_point()

p + coord_fixed(ratio = 1/3)
p + coord_fixed(ratio = 3/1)




## ---- 4. Combinando gráficos ----------------------------------------------------------------------------
## ---- 4. Combinando gráficos ----------------------------------------------------------------------------

library(gridExtra)
p1 <- ggplot(iris, aes(Sepal.Length, Petal.Length, color = Species)) + geom_point()
p2 <- ggplot(iris)+ aes(Species, Sepal.Length) + geom_boxplot()

grid.arrange(p1, p2, ncol = 2, widths = c(6.5, 3.5))


## ---- eval = TRUE, out.width = "80%"-------------------------------------
library(patchwork)
p1 + p2 + plot_layout(ncol = 2)


## ------------------------------------------------------------------------
library(cowplot)
ggdraw(p1) +  draw_image("./imagenes/Captura.JPG", 
               x = 1, y = 1, hjust = 1, vjust = 1, width = 0.33, height = 0.42)


## ---- 5. Exportando gráficos ----------------------------------------------------------------------------
## ---- 5. Exportando gráficos ----------------------------------------------------------------------------

p <- ggplot(iris, aes(Sepal.Length, Petal.Length)) + geom_point()
p + geom_line()

ggsave("./graf_out/my_grafico_chulo.png", p, width = 15, height = 10)
ggsave("filename.png", plot = my_plot, width = 8, height = 6, units = "in", dpi = "retina")

# Tb funciona para figuras compuestas de varios gráficos
grafico_combinado <- grid.arrange(p1, p2, ncol = 2, widths = c(6, 4))
ggsave("fig_output/my_combo_plot.png", grafico_combinado, width = 10, dpi = 300)

# podemos guardar una copia completa del gráfico, no de su representación visual, sino del objeto R con
saveRDS(p, "plot.rds")
my_valioso_grafico <- readRDS("plot.rds")



## ---- 6. Tipos de gráficos ------------------------------------------------------------------------------
## ---- 6. Tipos de gráficos ----------------------------------------------------------------------------

#- 6.1 Histogramas -----------------

ggplot(iris, aes(Sepal.Length)) + geom_histogram() 


p <- ggplot(iris, aes(Sepal.Length))
p + geom_histogram(bins = 40) + xlab("40 intervalos")
p + geom_histogram(bins = 4) + xlab("Sólo 4 intervalos")


p <- ggplot(iris, aes(Sepal.Length))
p + geom_histogram(binwidth = 0.1) + xlab("He elegido la anchura = 0.1")
p + geom_histogram(binwidth = 1.1) + xlab("Esta vez la anchura = 1.1")



ggplot(iris, aes(Sepal.Length)) + 
  geom_histogram(aes(y = stat(count) / sum(count)), bins = 10) +
  scale_y_continuous(labels = scales::percent)


ggplot(iris, aes(Sepal.Length)) + geom_histogram(bins = 10, color = "black", fill = "tomato")


ggplot(iris, aes(Sepal.Length)) + geom_histogram(bins = 10, aes(fill = Species), color = "black")


p <- ggplot(iris, aes(Sepal.Length, fill = Species)) + geom_histogram(bins = 10, color = "black")
p + facet_grid(cols = vars(Species))

#- un ejmeplo útil
iris_backgroung <- iris %>% select(-Species)
ggplot(iris, aes(x = Sepal.Length)) +
  geom_histogram(data = iris_backgroung, fill = "grey", bins = 15) +
  geom_histogram(aes(fill = Species), bins = 15) +
  facet_grid(cols = vars(Species))


## ---- out.width = "85%"--------------------------------------------------
ggplot(iris, aes(Sepal.Length)) + 
  geom_density(color = "red",   size = 1.2) +  
  geom_density(color = "blue",  size = 1.2, adjust = 3) +
  geom_density(color = "black", size = 1.2, adjust = 0.5) +  xlim(2, 10)


## ------------------------------------------------------------------------
ggplot(iris, aes(Sepal.Length, fill = Species)) + geom_density(position = "stack", alpha = 0.5)


## ---- eval = FALSE-------------------------------------------------------
## ggplot(iris, aes(Sepal.Length, fill = Species)) + geom_density(position = "fill", alpha = 0.5) #- position = "fill"
## 
## ggplot(iris, aes(Sepal.Length, stat(count), fill = Species)) + geom_density(position = "stack", alpha = 0.5) #- stat(count)


## ------------------------------------------------------------------------
#- calculamos media y desviación tipica de Sepal.Length para luego usarlas para construir la curva normal
media <- mean(iris$Sepal.Length, na.rm = TRUE)     #- media de la longitud del sépalo
desviacion <- sd(iris$Sepal.Length, na.rm = TRUE)  #- desviación 

#- hacemos el histograma
p <- ggplot(iris, aes(Sepal.Length)) +
      geom_histogram(aes(y=..density..),  color="black", fill = "steelblue", alpha = 0.2)

#- le añadimos la densiidad estimada y la normal
p + geom_density( color="purple", size = 1) +
    stat_function(fun = dnorm, colour = "red", size = 1, args = list(mean = media, sd = desviacion))  + 
    xlim(c(min(iris$Sepal.Length)-1, 9))



## ------------------------------------------------------------------------
library(ggridges)
ggplot(iris, aes(x = Sepal.Length, y = Species)) + geom_density_ridges(aes(fill = Species), alpha = 0.5)


## ------------------------------------------------------------------------
library(viridis)
ggplot(lincoln_weather, aes(x = `Mean Temperature [F]`, y = `Month`, fill = ..x..)) +
  geom_density_ridges_gradient(scale = 3, rel_min_height = 0.01) +
  scale_fill_viridis(name = "Temp. [F]", option = "C") +
  labs(title = 'Temperatures in Lincoln NE in 2016')


## ------------------------------------------------------------------------
ggplot(iris, aes(Sepal.Length, Petal.Length, color = Species)) + 
     geom_point() +
     labs(title = "Gráfico 1: Longitud del sépalo frente al pétalo",
       subtitle = "(diferenciando por especie de lirio)",
       caption = "Datos provenientes del Iris dataset",
       x = "Longitud del sépalo",
       y = "Longitud del pétalo",
       color = "Especie de lirio")


## ---- eval = FALSE-------------------------------------------------------
set.seed(1234)
df <- data.frame(x = rnorm(2000), y = rnorm(2000))   #- creamos un conjuto de datos con 2000 observaciones y 2 v.
p <- ggplot(df, aes(x, y)) + xlab(NULL) + ylab(NULL)
p + geom_point()
p + geom_point(shape = 1) # Hollow circles
p + geom_point(shape = ".") # Pixel sized
#- For larger datasets with more overplotting, you can use alpha blending (transparency) t
p + geom_point(alpha = 1 / 10)




## ---- eval = FALSE-------------------------------------------------------
p + geom_bin2d()
p + geom_bin2d(bins = 10)
p + geom_hex()
p + geom_hex() + scale_fill_gradient2(low = "#132B43", high = "#56B1F7")



## ------------------------------------------------------------------------
#devtools::install_github("LKremer/ggpointdensity")
library(viridis)
library(ggpointdensity)
p +  geom_pointdensity(adjust = 7) +
  scale_color_viridis()



## ------------------------------------------------------------------------
ggplot(iris, aes(x = Species,  y = Sepal.Length)) + geom_boxplot() 


## ------------------------------------------------------------------------
p <- ggplot(iris, aes(x = Species,  y = Sepal.Length)) 
p + geom_boxplot(aes(fill = Species), outlier.colour = "purple")


## ------------------------------------------------------------------------
p <- ggplot(iris, aes(x = Species,  y = Sepal.Length)) + geom_boxplot(aes(fill = Species)) 
p + coord_flip()


## ------------------------------------------------------------------------
p + geom_jitter(width = 0.15, alpha = 1/4, color = "tomato")


## ------------------------------------------------------------------------
p + stat_summary(fun.y = "mean", geom = "point", color = "purple", size = 2.5)


## ---- eval = FALSE-------------------------------------------------------
p <- ggplot(iris, aes(x = Species,  y = Sepal.Length))
p + geom_violin(aes(fill = Species), alpha = 0.6)
p + geom_violin(aes(fill = Species), alpha = 0.6) + geom_jitter(width = 0.15, alpha = 1/4)




## ------------------------------------------------------------------------
ggplot(iris, aes(x = Species,  y = Sepal.Width)) + geom_boxplot()


## ------------------------------------------------------------------------
ggplot(iris, aes(x = reorder(Species, Sepal.Width, mean),  y = Sepal.Width)) + geom_boxplot() +
  xlab("De menor a mayor anchura del sépalo")


## ---- eval = FALSE-------------------------------------------------------
p <- ggplot(mpg, aes(class))
p + geom_bar()
p + geom_bar(fill = "steelblue") + coord_flip()


## ------------------------------------------------------------------------
df <- mpg %>% group_by(class) %>% count
p <- ggplot(df, aes(x = class, y = n))
p + geom_bar(stat = "identity",  fill = "steelblue") 
# p + geom_col(fill = "steelblue")                          #- hace exactamente el mismo plot


## ---- eval = FALSE-------------------------------------------------------
ggplot(mtcars, aes(factor(cyl), fill = factor(vs))) + geom_bar() #- pos
ggplot(mtcars, aes(factor(cyl), fill = factor(vs))) + geom_bar(position = "fill")
ggplot(mtcars, aes(factor(cyl), fill = factor(vs))) + geom_bar(position = "dodge")
ggplot(mtcars, aes(factor(cyl), fill = factor(vs))) + geom_bar(position = position_dodge2(preserve = "single"))



## ------------------------------------------------------------------------
df <- mpg
df <- df %>% mutate(class = forcats::as_factor(class)) #- convertimos la v. class a factor con la f. as_factor()
df <- df %>% mutate(class = forcats::fct_infreq(class)) #- fct_infreq() los niveles del factor según su frecuencia de mayor a menor
p <- ggplot(df, aes(fct_rev(class))) #- fct_rev() ordena los levels de menor a mayor
p + geom_bar(fill = "steelblue") + coord_flip()


## ------------------------------------------------------------------------
p + geom_bar(fill = "steelblue") + coord_flip() +
    geom_text(stat='count', aes(label = ..count.. ), hjust = -0.15, size = 3.25) 


## ------------------------------------------------------------------------
p <- ggplot(df, aes(fct_rev(class))) #- fct_rev() ordena los levels de menor a mayor
p + geom_bar(aes( y = (..count..)/sum(..count..)), fill = "steelblue")  + coord_flip()


## ------------------------------------------------------------------------
ggplot(economics, aes(date, uempmed)) + geom_line()


## ------------------------------------------------------------------------
library(gapminder)
gapminder %>% filter(country == "Spain") %>% 
ggplot(aes(x = year, y = lifeExp)) + geom_line() + geom_point()


## ------------------------------------------------------------------------
gapminder %>% filter(country %in% c("Spain", "France", "Norway", "Belgium")) %>% 
ggplot(aes(x = year, y = lifeExp, color = country)) + geom_line() + geom_point()


## ------------------------------------------------------------------------
df <- gapminder %>% filter(country %in% c("Spain", "France", "Norway", "Belgium")) 
lifeExp_ends <- df %>% group_by(country) %>% top_n(1, year) %>% pull(lifeExp) #- vector con los valores últimos de lifeExp
ggplot(df, aes(x = year, y = lifeExp, color = country)) + geom_line() + 
     scale_y_continuous(sec.axis = sec_axis(~ ., breaks = lifeExp_ends)) +   #- sec_axis() especifica un eje secundario
     scale_x_continuous(expand = c(0, 0))


## ------------------------------------------------------------------------
library(tidyquant)
stocks <- c("GOOGL","AMZN","FB","AAPL") #- seleccionamos a las GAFAs
df <- tq_get(stocks, from = as.Date("2013-01-01"), to = as.Date("2013-12-31"))

ggplot(df, aes(date, y = close, color = fct_reorder2(symbol, date, close))) +
  geom_line() + xlab("") + ylab("") +
  theme(legend.title = element_blank())


## ------------------------------------------------------------------------
df <- df %>% group_by(symbol) %>% mutate(rescaled_close = 100*close / close[1])

ggplot(df, aes(date, y = rescaled_close, color = fct_reorder2(symbol, date, rescaled_close))) +
  geom_line() + xlab("") + ylab("") +
  theme(legend.title = element_blank())


## ------------------------------------------------------------------------
library(quantmod)
today <- Sys.Date()
three_months_ago <- seq(today, length = 2, by = "-3 months")[2]
getSymbols("AAPL", from = three_months_ago, to = today)
candleChart(AAPL, theme = 'white', type = 'candles')


## ------------------------------------------------------------------------
p <- ggplot(iris, aes(Sepal.Length, Petal.Length)) + 
     geom_point() 
p + geom_smooth(method = "lm", formula = y ~ poly(x,4))


## ------------------------------------------------------------------------
p <- ggplot(iris, aes(Sepal.Length, Petal.Length)) + 
     geom_point()
p + geom_smooth(aes(color = "loess") , method = "loess", se = FALSE) + 
    geom_smooth(aes(color = "lm")    , method = "lm"   , se = FALSE)


## ------------------------------------------------------------------------
ggplot(NULL, aes(x = c(-20, 20))) +
  stat_function(fun = function(x) { x**3 },
                geom = "line")


## ------------------------------------------------------------------------
ggplot(NULL, aes(x = c(-3, 3))) +
  stat_function(fun = dnorm,
                geom = "line")


## ------------------------------------------------------------------------
ggplot(NULL, aes(x = c(-5, 5))) +
  stat_function(fun = dnorm, geom = "line", xlim = c(-4, 0)) +
  stat_function(fun = dnorm, geom = "area", fill = "steelblue", xlim = c(0, 4)) +
  xlim(-5, 5)


## ------------------------------------------------------------------------
library(ggrepel)
df <- gapminder::gapminder %>% filter(year == "2007")  %>% filter(continent == "Europe")
ggplot(df, aes(gdpPercap, lifeExp, label = country)) + geom_point() +
     labs(title = "Gráfico 1: Esperanza de vida frente a PIB per cápita" ,
       caption = "Datos provenientes de gapminder",
       y = "lifeExp",
       x = "gdpPercap") + geom_smooth() +
        geom_label_repel() 


## ------------------------------------------------------------------------
library(GGally)
ggpairs(iris)
ggpairs(iris %>% select(1:4) %>% na.omit(), progress = FALSE, lower = list(combo = wrap("facethist", bins=6)))


## ------------------------------------------------------------------------
presidential <- subset(presidential, start > economics$date[1])

p <- ggplot(economics) +  geom_line(aes(date, unemploy)) + 
  scale_fill_manual(values = c("blue", "red")) +
  xlab("date") + 
  ylab("unemployment")

#- comienzan las anotaciones  
p + geom_rect(aes(xmin = start, xmax = end, fill = party), 
              ymin = -Inf, ymax = Inf, alpha = 0.2, data = presidential) + 
    geom_vline(aes(xintercept = as.numeric(start)), 
               data = presidential, colour = "grey50", alpha = 0.5) + 
    geom_text(aes(x = start, y = 2500, label = name), 
               data = presidential, size = 3, vjust = 0, hjust = 0, nudge_x = 50) 


## ------------------------------------------------------------------------
p <- ggplot(mpg, aes(displ, hwy)) +
  geom_point(data = filter(mpg, manufacturer == "subaru"), colour = "orange", size = 3) +
  geom_point() 
p


## ------------------------------------------------------------------------
p + annotate(geom = "point", x = 5.5, y = 40, colour = "orange", size = 3) + 
    annotate(geom = "point", x = 5.5, y = 40) + 
    annotate(geom = "text", x = 5.6, y = 40, label = "subaru", hjust = "left")


## ------------------------------------------------------------------------
p + annotate(geom = "curve", x = 4, y = 35, xend = 2.65, yend = 27, 
              curvature = .3, arrow = arrow(length = unit(2, "mm"))) +
   annotate(geom = "text", x = 4.1, y = 35, label = "subaru", hjust = "left")


## ------------------------------------------------------------------------
ggplot(iris, aes(Sepal.Length, Petal.Length)) +
  geom_point(aes(color = Species)) + 
  ggforce::geom_mark_ellipse(aes(label = Species, group = Species))


## ------------------------------------------------------------------------
ggplot(iris, aes(Petal.Length, Petal.Width, colour = Species)) +
  geom_point() +
  ggforce::facet_zoom(x = Species == "versicolor")


## ------------------------------------------------------------------------
df <- gapminder::gapminder %>% filter(continent == "Europe")
ggplot(df, aes(year, lifeExp, group = country)) + 
  geom_line() + 
  geom_point() + 
  gghighlight::gghighlight(country %in% c("Spain", "Portugal"))


## ------------------------------------------------------------------------
ggplot(iris, aes(Sepal.Length, Petal.Length, color = as.factor(Species))) +
  geom_point() + 
  gghighlight::gghighlight() + 
  facet_wrap(vars(Species))


## ---- eval = FALSE-------------------------------------------------------
library(plotly)
p <- ggplot(iris, aes(Sepal.Length, Petal.Length, color = Species)) +  geom_point() + geom_smooth()
ggplotly(p)


## ---- eval = FALSE-------------------------------------------------------
p1 <- p + facet_grid(cols = vars(Species))
ggplotly(p1)
 


## ---- eval = FALSE-------------------------------------------------------
p <- ggplot(mpg, aes(class)) +  geom_bar(fill = "steelblue") + coord_flip()
ggplotly(p)


## ---- eval = FALSE-------------------------------------------------------
library(leaflet)
m <- leaflet()
m <- addTiles(m)
m <- addMarkers(m, lng = 174.768, lat =-36.852, popup = "The birthplace of R")
m


## ---- eval = FALSE-------------------------------------------------------
library(tidyverse)
library(gapminder)
library(gganimate)
gapmider_europe <- gapminder %>% filter(continent == "Europe")
ggplot(gapmider_europe, aes(gdpPercap, lifeExp, size = pop, colour = country)) +
     geom_point(alpha = 0.7, show.legend = FALSE) +
     scale_colour_manual(values = country_colors) +
     scale_size(range = c(2, 12)) +
     scale_x_log10() +
     facet_wrap(~continent) 
     # Here comes the gganimate specific bits
##   labs(title = 'Year: {frame_time}', x = 'GDP per capita', y = 'life expectancy') +
##   transition_time(year) +
##   ease_aes('linear')

