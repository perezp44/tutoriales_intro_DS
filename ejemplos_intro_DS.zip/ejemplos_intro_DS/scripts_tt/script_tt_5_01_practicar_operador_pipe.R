#---- TUTORIAL 5: script para practicar el  OPERADOR PIPE %>% 
library(magrittr)  #- Ceci n'est pas une pipe ( %>% )


#- la función head() muestra (por defecto) las primeras 6 observaciones de un df
head(iris)           

iris %>% head(.)
iris %>% head()
iris %>% head

#- muestra las primeras 4 observaciones
head(iris, n = 4)    

iris %>% head(. , n = 4)
iris %>% head( , n = 4)
iris %>% head(n = 4)

#- para terminar de entender %>% 

4 %>% head(iris) #- xq no va


4 %>% head(iris, n = .)

4 %>% head(iris, .)


# LETTERS ---------------------------------------------------

letters %>% paste0( "--" ,  .  ,  "!!" ) %>% toupper

#- para entender paste0 y toupper
aa <- paste0("hola","tete")
toupper(aa)
paste(letters, 1:10)
paste("X_" , 1:7, sep = "")

#- para entender letters
find("letters")
help("letters")


#- Bueno ya sabemos que hace esta linea de código
  
letters %>% paste0( "--" ,  .  ,  "!!" ) %>% toupper


#- ¿Cómo escribiriamos la misma secuencia de instrucciones con R-base?

toupper(paste0( "--", letters, "--"))




#- algo muy simple (para afianzar %>% )

1 %>% sqrt %>% log

log(sqrt(1)) #- en   R-base





#(!!!!)------------- BONUS: The input to the pipeline can itself be a placeholder!!
iris <- iris
unique(iris$Species)               #- devuelve un factor
length(unique(iris$Species))       #- 3 valores únicos
length(unique(iris$Sepal.Length))  #- 35 valores únicos



num_unique <- . %>% unique %>% length

class(num_unique)  #- es una secuencia de funciones

num_unique(iris$Species)
num_unique(iris$Sepal.Length)
find("num_unique") #- esta función está definida en el Global Environement

#- comprobemos si nuestra secuencia de funciones funciona (!!)
iris$Species %>% num_unique
iris$Sepal.Length %>% num_unique


#- Podriamos crear una función equivalente utilizando la forma estándar así:

my_f <- function(.) length(unique(.)) 

my_f(iris$Species)

#- o así:

my_f2 <- function(xx) {
         length(unique(xx)) 
       }

my_f2(iris$Species)


