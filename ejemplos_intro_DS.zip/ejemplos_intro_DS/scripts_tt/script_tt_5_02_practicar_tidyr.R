#---- TUTORIAL 5: script para practicar con tidyr (gather() y spread())
#- ahora pivot_longer() y pivot_wider()

#- ejemplo para practicar con tidyr 
library(tidyverse)

#----------------------------------------- DATA 1
data_1 <- data.frame(year = c("2014", "2015", "2016"),  Pedro = c(100, 500, 200), Carla = c(400, 600, 250), Maria = c(200, 700,900 ) )

#- este bloque de instrucciones puede que os resulten complicadas porque nos hemos saltado el tutorial de R-base
#- en data_1 los individuos están en columnas, así que vamos a intentar "arreglarlos" con la f. t()

#------------------------ no funciona 
aa <- t(data_1)
class(aa)  #- aa es una matríz
aa <- as.data.frame(t(data_1))

#----------------------  con R-base (no lo podeís entender xq nos hemos saltado el tutorial de R-base)
aa <- t(data_1[,2:ncol(data_1)])  #- trasponemos los datos (pero no la primera columna)
colnames(aa) <- data_1[,1]        #- ponemos como colnames los valores de la primera columna
aa <- as.data.frame(aa)           #- convertimos a df     

#---------------------- con tidyr (3 formas alternativas de hacerlo)
#- este bloque no lo podeis entender bien hasta que expliquemos las funciones
#- tidyr::gather() y tidyr::spread()
aa <- data_1 %>% gather(Nombre, Salario, 2:ncol(data_1))  %>%  spread(year, Salario) 
aa <- data_1 %>% gather(Nombre, Salario, 2:4)  %>%  spread(year, Salario)
aa <- data_1 %>% gather(Nombre, Salario, Pedro:Maria)  %>%  spread(year, Salario)


rm(aa, data_1)


#- las intrucciones de más abajo sí que ya hay que ir entendiéndolas

#------------------------------------------- DATA 2
data_2 <- data.frame( names = c("Pedro", "Carla", "María"), W_2014 = c(100, 400, 200), W_2015 = c(500, 600, 700),  W_2016 = c(200, 250, 900))

#- data_2 está en formato ancho (wide)
data_wide <- data_2
rm(data_2)

#- la función gather() transforma los datos de formato ancho(wide) a formato largo(long)
data_long <- data_wide %>% gather(periodo, salario, 2:4)

#- ya está, pero si queremos quitar el "W_" se puee hacer de muchas maneras; p.ejemplo con gsub()
#- esto solo lo entendereis bien-bien cuando hayamos hecho un par de clases más
data_long <- data_long %>% mutate(periodo = gsub("W_", "" , periodo))

#- a veces tendremos que hacer lo contrario; es decir, pasar de long a wide
#- spread() convierte un df de long a wide
data_wide_2 <- data_long %>% spread(periodo, salario)


#- desde el 13 de septiembre podemos usar las funciones 
#- pivot_longer() y pivot_wider() en lugar de gather() y spread()
#- en ppio vosostros os instalasteis los paquetes despues del 13 de septiembre, 
#- asi que en ppio no tendreis que actualizar tidyr con install.packages("tidyr")
#- Recordad q cuando vayais a instalar/actualizar un paquete es mejor hacerlo despues de hacer un "Restart R"

#- empecemos con tidyr::pivot_longer()
data_long_1 <- data_wide %>% gather(periodo, salario, 2:4) #- asi lo haciamos antes
data_long_2 <- data_wide %>% pivot_longer(2:4)
data_long_3 <- data_wide %>% pivot_longer(2:4, "periodo", "salario" ) #- así se hace ahora. 
data_long_4 <- data_wide %>% pivot_longer(2:4, names_to = "periodo", values_to = "salario" ) #- así se hace ahora. 
data_long_5 <- data_wide %>% pivot_longer(2:4, names_to = "periodo", values_to = "salario", 
                                          names_prefix = "W_") #- Si además quieres quitar "W_", puedes usar names_prefix = "W_"

#- ahora tidyr::pivot_wide() para pasar de long a wide
data_wide_1 <- data_long %>% spread(periodo, salario) #- así lo haciamos antes
data_wide_2 <- data_long %>% pivot_wider(names_from = periodo, values_from = salario) #- así se hace ahora

rm(list = ls()) #- dejamos limpio el Global environment. Borramos todos sus objetos

#------------------- tidyr::separate() y tidyr::unite()
df <- data.frame(names = c("Pedro Navaja", "Bob Dylan", "Cid Campeador"), year  = c(1978, 1941, 1048) )

# separate()
df_a <- df %>% separate(names, c("Nombre", "Apellido"), sep = " ")


# unite()
df_b <- df_a %>% unite(Nombre_y_Apellido, Apellido:Nombre, sep = ", ")



