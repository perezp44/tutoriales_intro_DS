#- https://dbplyr.tidyverse.org/
#- dbplyr is designed to work with database tables as if they were local data frames. To demonstrate this I’ll first create an in-memory SQLite database and copy over a dataset:

library(tidyverse)

con <- DBI::dbConnect(RSQLite::SQLite(), ":memory:")
copy_to(con, mtcars)
copy_to(con, iris)



mtcars2 <- tbl(con, "mtcars")
iris2   <- tbl(con, "iris")


# primera query
query_1 <- mtcars2 %>% group_by(cyl) %>%
                       summarise(mpg = mean(mpg, na.rm = TRUE)) %>%
                       arrange(desc(mpg))

query_1 %>% show_query()

# segunda query
query_2 <- iris2 %>% count()
query_2 %>% show_query()
