#- https://gist.github.com/thomasp85/9362bbfae956f2690794abeb2c11cdcc

library(ggplot2)
library(gganimate)
library(sf)
earth <- sf::st_as_sf(rnaturalearth::countries110)
views <- data.frame(rbind(
  st_bbox(earth[earth$name == 'Spain',]),
  st_bbox(earth[earth$name == 'Australia',])
))
p <- ggplot() +
  geom_sf(data = earth, fill = 'white') +
  geom_sf(data = earth[earth$name %in% c('Spain', 'Australia'),], fill = 'forestgreen') +
  theme(panel.background = element_rect('lightblue')) +
  view_zoom_manual(1, 1, xmin = views$xmin, xmax = views$xmax, ymin = views$ymin, ymax = views$ymax, wrap = TRUE)
animacion <- animate(p, 100, 10)

animacion
