#- voy a usar unos datos del callejero valenciano

library(tidyverse)
library(sf)
#library(LAU2boundaries4spain)  #- devtools::install_github("perezp44/LAU2boundaries4spain", force = TRUE)


#- cargamos datos
distritos <- st_read("./datos/maps_valencia/Valencia_districts/DISTRITOS.shp") #- +proj=utm +zone=30 +ellps=GRS80 +units=m +no_defs
calles <- st_read("./datos/maps_valencia/Valencia_street_axis/EJES-CALLE.shp") #- +proj=utm +zone=30 +ellps=GRS80 +units=m +no_defs

#- para verlos mejor
distritos_xx <- distritos %>% st_set_geometry(NULL)
calles_xx <- calles %>% st_set_geometry(NULL)

#- graficos
ggplot() + geom_sf(data = distritos)
ggplot() + geom_sf(data = distritos) + geom_sf(data = calles)

#- agrupando los tramos de las calles
calles_dd <- calles %>% group_by(nomcalle) %>% summarise
ggplot() + geom_sf(data = distritos) + geom_sf(data = calles_dd)

#- calculando distancias de las calles
calles_dd_l <- calles_dd %>% mutate(largo = st_length(geometry))

#- cargo geometrias de los municipios españoles
municipios_2017 <- rio::import("https://github.com/perezp44/LAU2boundaries4spain/blob/master/data/municipios_2017.rda?raw=true")
muni    <- municipios_2017   #- +proj=longlat +ellps=GRS80 +no_defs
muni_xx <- muni %>% st_set_geometry(NULL)
zz <- muni_xx %>% group_by(INECodProv, NombreProv) %>% count() #- para ver como se llama la provincia de Valencia


muni_valen <- muni %>% filter(NombreProv == "Valencia/València")   #- +proj=longlat +ellps=GRS80 +no_defs
muni_valen_a <- muni_valen %>% st_transform("+proj=utm +zone=30 +ellps=GRS80 +units=m +no_defs")

ggplot() + geom_sf(data = muni_valen_a) + geom_sf(data = distritos) + geom_sf(data = calles)


#- vamos a ver si graficamos los municipios colindantes a Valencia
valencia <- muni_valen_a %>% filter(NombreMuni == "Valencia")
zz <- st_touches(muni_valen_a, valencia, sparse = FALSE, prepared = TRUE)
junto_valencia <- muni_valen_a %>% filter(zz)
ggplot() + geom_sf(data = junto_valencia) + geom_sf(data = distritos) + geom_sf(data = calles)


