#- quiero hacer un grafico con los puntos de long, lat de los municipios, tal y comos e hace aqui:
#- https://rviews.rstudio.com/2019/09/19/intro-to-ggforce/
#devtools::install_github("perezp44/spanishRentidadesIGN")
library(spanishRentidadesIGN)
municipios <- IGN_nomencla_muni
prov <- IGN_nomencla_prov


library(tidyverse)
library(ggforce)

p <- municipios %>%
    filter(!COD_PROV %in% c(35,38)) %>%
    ggplot(aes(LONGITUD_ETRS89, LATITUD_ETRS89, color = COD_PROV)) +
    geom_point(show.legend = FALSE)  + ylim(c(35, 45))

p + ylim(c(35, 45))


p + ylim(c(35, 45)) + geom_mark_rect()

p + ylim(c(35, 45)) + geom_mark_rect(aes(label = PROVINCIA))

p + ylim(c(35, 45)) + geom_mark_hull(aes(label = PROVINCIA)) + theme_void()

#- Un grafico chulo con esto ultimo: http://kanaga.ridel.org/2019/09/13/premiere-tronc-commun-les-reperes-spaciaux/
#- los datos los saca de aqui: https://population.un.org/wup/Download/

p +  facet_zoom(xlim = c(-1, 5), ylim = c(42, 45))



