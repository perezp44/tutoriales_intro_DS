#- carga de datos para el tt_13

library(knitr)
library(here)
library(tidyverse)
library(patchwork)
library(ggrepel)

library(sf)
library(rnaturalearth)
library(rnaturalearthdata)
library(ggspatial)
library(spanishRpoblacion)     #- devtools::install_github("perezp44/spanishRpoblacion")
library(spanishRentidadesIGN)   #- devtools::install_github("perezp44/spanishRentidadesIGN")
library(mapview)
library(leafem)
library(leaflet)

#library(LAU2boundaries4spain) #- datos espaciales de Spain: ETRS89
#CCAA <- CCAA                  #- solo funciona si tienes el pkg LAU2boundaries4spain instalado. En el cloud no está
#Provincias <- Provincias            #- solo funciona si tienes el pkg LAU2boundaries4spain instalado.
#municipios_2017 <- municipios_2017  #- solo funciona si tienes el pkg LAU2boundaries4spain instalado.

CCAA <- rio::import("https://github.com/perezp44/LAU2boundaries4spain/blob/master/data/CCAA.rda?raw=true")
Provincias <- rio::import("https://github.com/perezp44/LAU2boundaries4spain/blob/master/data/Provincias.rda?raw=true")
municipios_2017 <- rio::import("https://github.com/perezp44/LAU2boundaries4spain/blob/master/data/municipios_2017.rda?raw=true")

world <- rnaturalearth::ne_countries(scale = "medium", returnclass = "sf")

#rios <- rio::import(here::here("datos", "Rios", "rio_ebro.rds"))
rios <- rio::import("https://github.com/perezp44/archivos_download/blob/master/rio_ebro.rds?raw=true")

pueblos <- data.frame(nombre = c("Pancrudo", "Valencia"), longitude = c(-1.028781, -0.3756572), latitude = c(40.76175, 39.47534)) #- ETRS89
pueblos_sf <- st_as_sf(pueblos, coords = c("longitude", "latitude"), crs = 4326, agr = "constant") #-



#- MAPVIEW

pueblos <- data.frame(nombre = c("Pancrudo", "Valencia"), longitude = c(-1.028781, -0.3756572), latitude = c(40.76175, 39.47534)) #- ETRS89
pueblos_sf <- st_as_sf(pueblos, coords = c("longitude", "latitude"), crs = 4326, agr = "constant") #- EPSG:4326 Coordenadas Geográficas WGS84

mapview::mapview(pueblos_sf)


mapview::mapview(CCAA)


library(spanishRpoblacion)
INE_padron_muni_96_17 <- INE_padron_muni_96_17
info_CCAAs <- INE_padron_muni_96_17 %>% filter(anyo == 2017) %>%
                 group_by(NombreCCAA) %>%
                 mutate(n_prov = n_distinct(INECodProv)) %>%
                 mutate(n_pueblos = n_distinct(INECodMuni)) %>%
                 mutate(pob_CCAA = sum(Pob_T, na.rm = TRUE)) %>% ungroup() %>%
                 select(INECodCCAA, n_prov, n_pueblos, pob_CCAA) %>%
                 distinct() %>% ungroup()


CCAA_con_info <- left_join(CCAA, info_CCAAs,  by = c("INECodCCAA" = "INECodCCAA"))



mapview::mapview(CCAA_con_info,
                 zcol = c("NombreCCAA", "n_prov", "n_pueblos", "pob_CCAA"),
                 color = "tomato", col.regions = "purple", lwd = 1,
                 cex = "n_pueblos")


mapview::mapview(CCAA_con_info,
                 zcol = c("NombreCCAA", "n_prov", "n_pueblos", "pob_CCAA"),
                cex = "n_pueblos")


mapview::mapview(CCAA_con_info, zcol = c("NombreCCAA", "n_prov", "n_pueblos", "pob_CCAA")) +
mapview::mapview(pueblos_sf)


CCAA_con_info %>% st_union %>% mapview

### Integración con el paquete `mapedit`
#install.packages("mapedit")
library(mapedit)
my_map <- mapview(pueblos_sf)
drawFeatures(my_map, editor = "leafpm")   #- good


library(mapedit)
mys_dibujitos <- editMap(mapview(pueblos_sf))
mapview(mys_dibujitos$finished)


# 6. Paquete `leaflet` ------------------------------------------------------------------------------------------------

library(leaflet)
leaflet() %>% addTiles() %>% leafem::addMouseCoordinates()


m <- leaflet() %>%
  addTiles() %>%
  setView(lng = -1.0287810, lat = 40.76175, zoom = 6) %>%
  addMarkers(lng = -1.0287810, lat = 40.76175, popup = "Pancrudo") %>%
  addPopups(lng = -0.3756572, lat = 39.47534, popup = "Valencia")
m


leaflet() %>%
  addTiles() %>% # Add default OpenStreetMap map tiles
  addCircleMarkers(data = pueblos_sf)
  #leafem::addHomeButton(ext = extent(breweries91), layer.name = "pueblos")



leaflet(data = CCAA) %>% addTiles() %>%
  addPolygons(fillColor = topo.colors(18, alpha = NULL), stroke = FALSE)

CCAA_wgs84  <- CCAA %>% st_transform("+proj=longlat +datum=WGS84")
leaflet(data = CCAA_wgs84) %>% addTiles() %>%
  addPolygons(fillColor = topo.colors(18, alpha = NULL), stroke = FALSE)
