#- script para generar a bunch of parametrised reports
#- para ello tenemos que utilizar la función: rmarkdown::render()
#- por ejemplo:
# rmarkdown::render(input = "./my_parametrised_report.Rmd", params = list(municipio = "Valencia", periodo = "2017"), output_file = "./reports/report_xx.html"  )


library(tidyverse)

#- los informes se crearán en el directorio "./reports", así que teneis que crear ese directorio en vuestro Rproject
#- podeis hacerlo así:
fs::dir_create("./reports/")

#- vamos a hacer el informe primero solo para un conjunto de municipios  (para un solo periodo, p.ej: año 2010)
municipios <- c("Valencia", "Alzira")
nombres_de_los_informes <- paste0("./reports/", municipios)

#- acuerdate de poner en el YAML: `r my_HEADER`

for (ii in 1:length(municipios)) {
  my_MUNICIPIO <- municipios[ii]
  my_HEADER <- glue::glue("Informe para ", {my_MUNICIPIO} , " (Año 2010)")
     rmarkdown::render(
              input = "./my_parametrised_report.Rmd", 
              params = list(municipio = my_MUNICIPIO, periodo = 2010),
              output_file = nombres_de_los_informes[ii]  )
}
          
        

#- ahora lo hacemos tb para varios peridos -------------------------------
municipios <- c("Valencia", "Alzira")
anyitos <- c(2010, 2017)
#- voy a generar el nombre de los informes
zz <- expand.grid(municipios, anyitos) 
zzz <- zz %>% tidyr::unite(new_col, Var1, Var2, sep = "_") %>% pull()
nombres_de_los_informes <- paste0("./reports/", zzz)
matriz_nombres <- matrix(data = nombres_de_los_informes, nrow = 2, ncol = 2)


for (ii in 1:length(municipios)) {
  my_MUN <- municipios[ii]
    for (jj in 1:length(anyitos)) {
      my_ANY <- anyitos[jj]
      my_HEADER <- glue::glue("Informe para ", {my_MUN} , " (Año ", {my_ANY}, ")")
          rmarkdown::render(
            input = "./my_parametrised_report.Rmd", 
            params = list(municipio = my_MUN, periodo = my_ANY),
            output_file = matriz_nombres[ii,jj]  )
    }
}
          
          
          
          