#- package para hacer memes: https://github.com/GuangchuangYu/meme/
# install.packages("meme")

library(meme)
vignette("meme", package = "meme")

u <- system.file("success.jpg", package = "meme")
meme(u, "SÍ q puedes!!!", "Tú puedes aprender R!!", size = 2.0, color = "purple")

u <- "./imagenes/Captura.JPG"
meme(u, "Claro que puedes!!", "Te lo dice NV", size = 2.7, color = "orange")



